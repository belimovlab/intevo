<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['menu_active'] = 'main';
           $test = '';
           $this->data['slider'] = $this->db->order_by('id','desc')->where('url != ',$test)->get('slider')->result();
           $this->data['header'] = $this->reload_header();
           $this->data['footer'] = $this->reload_footer();
           
       }



        public function index()
        {
            $this->data['more'] = $this->db->get('more')->row();
            $this->data['houses'] = $this->db->limit(4)->order_by('id','desc')->get('house')->result();
            $this->data['top_6'] = $this->db->limit(6)->order_by('id','asc')->get('goods_catalog')->result();
            $this->data['top_news'] = $this->db->limit(1)->order_by('id','desc')->get('news')->row();
            $this->data['top_news_3'] = $this->db->limit(3,1)->order_by('id','desc')->get('news')->result();
            $this->load->view('main_index',  $this->data);
        }
        
        public function show_404()
        {
            $this->data['menu_active'] = '2';
            $this->data['header'] = $this->reload_header('404 ошибка! Нет такой страницы.');
            $this->load->view('main_show_404',  $this->data);
        }
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */