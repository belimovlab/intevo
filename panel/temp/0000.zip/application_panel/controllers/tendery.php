<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tendery extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 11;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['header'] = $this->reload_header('Редактирование информации');
            $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
            $this->data['success'] = $this->session->userdata('success');
            $this->session->unset_userdata('success');
            $this->data['more_tendery'] = $this->db->select('tendery')->get('more')->row();
            $this->load->view('more/tendery',  $this->data);
        }
        

        
        public function save_tendery()
        {
            $this->db->update('more',array('tendery'=>$this->input->post('more_tendery') ));
            $this->session->set_userdata('success','Информация успешно изменена.');
            redirect('/tendery');
        }
        
       
       
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */