<?php echo $header;?>

			<div class="production nedvizhimost">
				<div class="container">
					<div class="left-sidebar">
						<div class="menu-wrapper">
							<p class="left-sidebar-title no-icon-sidebar-title">Тип недвижимости</p>
							<ul class="sidebar-menu">
                                                            <li><a href="<?php echo base_url('/nedvizhimost')?>" class="active">Жилая</a></li>
                                                            <li><a href="<?php echo base_url('/parking')?>">Парковочные места</a></li>
							</ul>
						</div>
						<div class="office-title">Офис продаж</div>
						<div class="office-contacts">
							<p class="adres"><?php echo $office_info->adres;?></p>
							<p class="tel"><span><?php echo $office_info->phone;?></span></p>
							<p class="fax"><?php echo $office_info->fax;?></p>
							<a class="mail" href="mailto:<?php echo $office_info->email;?>"><?php echo $office_info->email;?></a>
						</div>
						<div class="banner">
							<img src="/img/banner_4.png" alt="">
						</div>
                                                <?php foreach($top_3_ned as $one):?>
                                                
						<div class="news-item">
                                                    <a href="<?php echo base_url('/pages/'.$one->url)?>"><?php echo $one->title?></a>
                                                    <p><?php echo $one->content; ?></p>
						</div>
                                                <?php endforeach;?>
					
					</div>
					<div class="right-block">
						<div class="broods">
							<ul>
								<li><a href="<?php echo base_url('/')?>">Главная</a></li>
								<li><a href="<?php echo base_url('/nedvizhimost')?>">Недвижимость</a></li>
							</ul>
						</div>
						<p class="right-block-title">Поиск</p>
						<div id="tabs">
							<ul>
								<li><a href="#tabs-1"><span>Квартира</span></a></li>
							</ul>
							<div id="tabs-1">
                                                            <form action="<?php echo base_url('/nedvizhimost/search/')?>">

									<div class="radio-item">
										<span class="title">количество комнат: </span>
										<label class="num-1">
											<input type="radio" name="flat" value="1" checked>
											<span>1</span>
										</label>
										<label class="num-2">
											<input type="radio" name="flat" value="2">
											<span>2</span>
										</label>
										<label class="num-3">
											<input type="radio" name="flat" value="3">
											<span>3</span>
										</label>

									</div>
									<div class="slider-item">
										<span>Цена:</span>
										<div id="slider-price">
											<p>
												<input type="text" class="amount" name="cost" readonly>
											</p>
										</div>
										<span>млн. руб</span>
									</div>
									<div class="checkbox">
                                                                            <div class="select-item">
										<span class="title">Дом:</span>
										<select name="house">
                                                                                    <option value="all">Все дома</option>
                                                                                    <?php foreach($houses as $one):?>
											<option value="<?php echo $one->id?>"><?php echo $one->name?></option>
                                                                                    <?php endforeach;?>
										</select>
                                                                            </div>
									</div>
									<input class="search-btn" type="submit" value="Найти">
									<div class="clear"></div>
								</form>
							</div>

						</div>
                                                <!--
						<div class="map">
							<div id="map"><script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=TtlkGnbYPLLk9Req2zs2R2wbNh1Ej7-8&width=668&height=376&lang=ru_RU&sourceType=constructor"></script></div>
						</div>
                                                
                                                -->
						<p class="search-result"><span>Найдено <?php echo count($houses);?> объект(а)</span></p>
                                                
                                                <?php echo print_r($flat_new);?>
                                                <?php foreach($houses as $one):?>
                                                
						<div class="result-item">
                                                        <div class="photo"><a href="<?php echo base_url('/nedvizhimost/view/'.$one->id)?>"><img src="<?php echo $one->main_photo?>" alt=""></a></div>
							<div class="description-wrap">
								<p class="result-title"><?php echo $one->name;?></p>
								<a href="#" class="adres"><span>г. Омск, Центральный район</span></a>
								<div class="table">
									<table>
										<tr>
											<td>Этажей</td>
											<td><?php echo $one->floor?></td>
										</tr>
										<tr>
											<td>S квартир</td>
											<td><?php echo $one->square?> М2</td>
										</tr>
										<tr class="tr-bold">
											<td>квартир в продаже</td>
											<td><?php echo count($flat_new[$one->id])?></td>
										</tr>
										<tr class="tr-bold">
											<td>срок сдачи объекта</td>
											<td>4 квартал 2015</td>
										</tr>
										<tr class="tr-price">
											<td>цена </td>
                                                                                        <td><?php echo number_format($flat_new[$one->id]['min_cost'], 0, "", " ");?> - <?php echo number_format($flat_new[$one->id]['max_cost'], 0, "", " ");?>  руб</td>
										</tr>
									</table>
								</div>
								<div class="preim">
									<ul>
										<li class="item-1">Экологичность</li>
										<li class="item-2">Доступность</li>
										<li class="item-3">Детсад</li>
										<li class="item-4">школа</li>
										<li class="item-5">парк</li>
										<li class="item-6">инфраструктура</li>
									</ul>
								</div>
							</div>
						</div>
                                                <?php endforeach;?>
					</div>
				</div>
			</div>
<?php echo $footer;