<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/* 
 * Разработка Bepobox.ru
 * Связаться с авторами на сайте http://bepobox.ru
 */



class Auth {

    var $data;
    var $CI;
    
    
    function __construct() {
        $this->CI = &get_instance();
    }


    public function is_loggined()
    {
        if($this->CI->session->userdata('user_name'))
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
    

}

/* End of file Someclass.php */