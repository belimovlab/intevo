<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Войти в панель администратора</title>
    <link href="/panel_assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/panel_assets/css/bootstrap-reset.css" rel="stylesheet">
    <link href="/panel_assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="/panel_assets/css/style.css" rel="stylesheet">
    <link href="/panel_assets/css/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="/panel_assets/js/html5shiv.js"></script>
    <script src="/panel_assets/js/respond.min.js"></script>
    <![endif]-->
</head>
  <body class="login-body">
    <div class="container">
        <div class="form-signin">
            <h2 class="form-signin-heading">Панель администратора</h2>
            <div class="login-wrap">
                <?php if($error):?>
                    <p style="font-size: 12px; text-align: center; color: red;"><?php echo $error;?></p>
                <?php endif;?>
                <form action="<?php echo base_url('/login/try_login/').'/'?>" method="POST">
                    <input type="text" class="form-control" placeholder="Логин" name="login" autofocus>
                    <input type="password" class="form-control" placeholder="Пароль" name="password">
                    <button class="btn btn-lg btn-login btn-block" type="submit">Войти</button>
                </form>
            </div>
        </div>
    </div>
    <p style="font-size: 11px; text-align: center; padding-top: 5px;">Лицензия <strong>№55-0016701</strong></p>
  </body>
</html>
