<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tendery extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['menu_active'] = 'tendery';
           $this->data['header'] = $this->reload_header();
           $this->data['footer'] = $this->reload_footer();
       }



        public function index()
        {
            $this->data['top_news'] = $this->db->order_by('id','desc')->get_where('pages',array('type_page'=>5))->result();
            $this->data['tendery_info'] = $this->db->select('tendery')->get('more')->row();
            $this->data['header'] = $this->reload_header('Тендеры');
            $this->load->view('tendery_index',  $this->data);
        }
        
        
        public function view($id)
        {
            $this->data['page_info'] = $this->db->get_where('pages',array('id'=>$id,'type_page'=>5))->row();
            $this->data['top_news'] = $this->db->order_by('id','desc')->get_where('pages',array('type_page'=>5))->result();
            $title = $this->data['page_info']->title ? $this->data['page_info']->title  : 'Нет такой страницы';
            $this->data['header'] = $this->reload_header($title);
            $this->load->view('tendery_view',  $this->data);
        }
        
       
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */