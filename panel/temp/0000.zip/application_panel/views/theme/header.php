<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=1200px">
    <title><?php echo $title;?></title>
    <link href="/panel_assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/panel_assets/css/bootstrap-reset.css" rel="stylesheet">
    <link href="/panel_assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="/panel_assets/css/style.css" rel="stylesheet">
    <link href="/panel_assets/css/style-responsive.css" rel="stylesheet" />
    <!--[if lt IE 9]>
      <script src="/panel_assets/js/html5shiv.js"></script>
      <script src="/panel_assets/js/respond.min.js"></script>
    <![endif]-->
    <?php foreach($css as $one):?>
    <?php if($one):?>
        <link href="/panel_assets/css/<?php echo $one;?>.css" rel="stylesheet" />
    <?php endif;?>
  <?php endforeach;?>
  </head>
  <body>
  <section id="container" class="">
      <header class="header white-bg">
          <div class="sidebar-toggle-box">
              <div data-original-title="Свернуть или развернуть навигацию" data-placement="right" class="icon-reorder tooltips"></div>
          </div>
          <a href="<?php echo base_url()?>" class="logo" >DSK-<span>OMSK.RU</span></a>
          <div class="nav notify-row tooltips" id="top_menu" data-original-title="Лицензия на использование программного комплекса" data-placement="bottom" >
              <span style="padding-top: 5px; display: block; margin-left: -60px;">Лицензия на использование № 55-0016701 действует до <strong>бессрочно</strong></span>
          </div>
      </header>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <ul class="sidebar-menu">
                  <li class="<?php echo $menu_active == 1 ? 'active' : '' ;?>">
                      <a href="<?php echo base_url('/')?>">
                          <i class="icon-dashboard"></i>
                          <span>Рабочий стол</span>
                      </a>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 2 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-book"></i>
                          <span>Страницы сайта</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li class="<?php echo $sub_menu_active == 'pages' ? 'active' : '' ;?>"><a href="<?php echo base_url('/pages')?>">Список страниц</a></li>
                          <li class="<?php echo $sub_menu_active == 'pages/add' ? 'active' : '' ;?>"><a href="<?php echo base_url('/pages/add')?>">Создать страницу</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 8 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-list-alt"></i>
                          <span>Новости</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li class="<?php echo $sub_menu_active == 'news' ? 'active' : '' ;?>"><a href="<?php echo base_url('/news')?>">Список новостей</a></li>
                          <li class="<?php echo $sub_menu_active == 'news/add' ? 'active' : '' ;?>"><a href="<?php echo base_url('/news/add')?>">Добавить новость</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 3 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-building"></i>
                          <span>Жилые объекты</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li class="<?php echo $sub_menu_active == 'house' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('house')?>">Каталог объектов</a></li>
                          <li class="<?php echo $sub_menu_active == 'house/add' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('house/add')?>">Добавить объект</a></li>
                          <li class="<?php echo $sub_menu_active == 'house/info' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('house/info_config')?>">Информация</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 13 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-building"></i>
                          <span>Паркинг</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li class="<?php echo $sub_menu_active == 'parking' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('parking')?>">Каталог объектов</a></li>
                          <li class="<?php echo $sub_menu_active == 'parking/add' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('parking/add')?>">Добавить объект</a></li>

                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 6 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-list"></i>
                          <span>Продукция</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="<?php echo base_url('goods')?>">Каталог продукции</a></li>
                      </ul>
                  </li>
                  <li class="<?php echo $menu_active == 9 ? 'active' : '' ;?>">
                      <a class="" href="<?php echo base_url('/cariera')?>">
                          <i class="icon-user"></i>
                          <span>Карьера </span>
                      </a>
                  </li>
                  <li class="<?php echo $menu_active == 10 ? 'active' : '' ;?>">
                      <a class="" href="<?php echo base_url('/about')?>">
                          <i class="icon-info"></i>
                          <span>О компании </span>
                      </a>
                  </li>
                  <li class="<?php echo $menu_active == 11 ? 'active' : '' ;?>">
                      <a class="" href="<?php echo base_url('/tendery')?>">
                          <i class="icon-tasks"></i>
                          <span>Тендеры </span>
                      </a>
                  </li>
                  <li class="<?php echo $menu_active == 12 ? 'active' : '' ;?>">
                      <a class="" href="<?php echo base_url('/slider')?>">
                          <i class="icon-film"></i>
                          <span>Слайдер </span>
                      </a>
                  </li>
                  
                  <li class="<?php echo $menu_active == 4 ? 'active' : '' ;?>">
                      <a class="" href="<?php echo base_url('/mail_inbox')?>">
                          <i class="icon-envelope"></i>
                          <span>Сообщения </span>
                          <?php if($new_messages):?>
                          <span class="label label-danger pull-right mail-info"><?php echo $new_messages?></span>
                          <?php endif;?>
                      </a>
                  </li>
                  <li class="sub-menu <?php echo $menu_active == 7 ? 'active' : '' ;?>">
                      <a href="javascript:;" class="">
                          <i class="icon-glass"></i>
                          <span>Дополнительно</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li class="<?php echo $sub_menu_active == 'more/info' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('more/info')?>">Информация</a></li>
                          <li class="<?php echo $sub_menu_active == 'more/square' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('more/square')?>">Площадь</a></li>
                          <li class="<?php echo $sub_menu_active == 'more/contacts' ? 'active' : '' ;?>"><a class="" href="<?php echo base_url('more/contacts')?>">Контакты</a></li>
                      </ul>
                  </li>
                  <li>
                      <a class="" href="<?php echo base_url('/login/logout')?>">
                          <i class="icon-user"></i>
                          <span>Выйти</span>
                      </a>
                  </li>
              </ul>
          </div>
      </aside>
      <section id="main-content">
          <section class="wrapper">
  