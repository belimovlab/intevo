<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/tendery/save_tendery/')?>" method="POST">
                    <?php if($success):?>
                        <p style="color: green; text-align: center; font-size: 12px;"><?php echo $success;?></p>
                    <?php endif;?>
                    <p>
                        <label for="more_tendery">Информация на главной странице</label>
                        <textarea type="text" id="more_tendery" name="more_tendery"><?php echo $more_tendery->tendery ? htmlspecialchars($more_tendery->tendery) : '';?></textarea>
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Сохранить информацию</button>
                    </form>
                </section>
             </div>
        </section>
    </div>
</div>
<?php echo $footer;?>