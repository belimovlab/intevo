<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

        var $data;
        private function reload_header($title='',$css=''){
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }
        private function reload_footer($js= ''){
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        function __construct() {
            parent::__construct();
        }
        public function index()
        {
            if($this->auth->is_loggined())
            {
                redirect('/');
            }
            else
            {
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata('error');
                $this->load->view('login',  $this->data);
            }
        }
        public function try_login()
        {
            if($this->auth->is_loggined())
            {
                redirect('/');
            }
            else
            {
                $user_info = $this->db->get_where('admins',array(
                    'login'=>  $this->input->post('login'),
                    'password'=> md5($this->input->post('password'))
                ))->row();
                if($user_info->id)
                {
                    $this->session->set_userdata('user_name',$user_info->id);
                    redirect('/');
                }
                else
                {
                    $this->session->set_userdata('error','Логин или пароль введен неверено.');
                    redirect('/login');
                }
            }
        }
        public function logout()
        {
            $this->session->unset_userdata('user_name');
            redirect('/');
        }
               
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */