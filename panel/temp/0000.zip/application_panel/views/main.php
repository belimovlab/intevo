<?php echo $header;?>

	<div class="container_15">

            <div class="row state-overview">
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol terques">
                              <i class="icon-building"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $house_cnt?></h1>
                              <p>Жилых домов</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol blue">
                              <i class="icon-qrcode"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $flat_cnt?></h1>
                              <p>Квартир в продаже</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol yellow">
                              <i class="icon-shopping-cart"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $goods_cnt?></h1>
                              <p>Продукция</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol red">
                              <i class="icon-envelope"></i>
                          </div>
                          <div class="value">
                              <h1><?php echo $new_messages?></h1>
                              <p>Новых сообщений</p>
                          </div>
                      </section>
                  </div>
              </div>
            
            
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <div class="panel-body progress-panel">
                <div class="task-progress">
                    <h1>СТРАНИЦЫ</h1>
                    <p>Последние 5 страниц</p>
                </div>
            </div>
            <table class="table table-hover personal-task">
                <tbody>
                    <?php if(count($pages)>0):?>
                    <?php $i=1;?>
                    <?php foreach($pages as $one):?>
                    <tr>
                        <td><?php echo $i;?></td>
                        <td>
                            <?php echo $one->title;?>
                        </td>
                        <td>
                          <a  href="<?php echo base_url('/pages/edit/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                        </td>
                    </tr>
                    <?php $i++;?>
                    <?php endforeach;?>
                    <?php else:?>
                    <tr>
                        <td colspan="3">У вас нет ни одной страницы.</td>
                    </tr>
                    <?php endif;?>

                </tbody>
            </table>
        </section>
    </div>
</div>
         
            <div class="row">
                  <div class="col-lg-12">
                      <div class="border-head">
                          <h3>График продаж</h3>
                      </div>
                      <div class="custom-bar-chart">
                          <div class="bar">
                              <div class="title">ЯНВ</div>
                              <div class="value tooltips" data-original-title="80%" data-toggle="tooltip" data-placement="top" style="height: 80%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">ФЕВ</div>
                              <div class="value tooltips" data-original-title="50%" data-toggle="tooltip" data-placement="top" style="height: 50%;"></div>
                          </div>
                          <div class="bar ">
                              <div class="title">МАР</div>
                              <div class="value tooltips" data-original-title="40%" data-toggle="tooltip" data-placement="top" style="height: 40%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">АПР</div>
                              <div class="value tooltips" data-original-title="55%" data-toggle="tooltip" data-placement="top" style="height: 55%;"></div>
                          </div>
                          <div class="bar">
                              <div class="title">МАЙ</div>
                              <div class="value tooltips" data-original-title="20%" data-toggle="tooltip" data-placement="top" style="height: 20%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">ИЮН</div>
                              <div class="value tooltips" data-original-title="39%" data-toggle="tooltip" data-placement="top" style="height: 39%;"></div>
                          </div>
                          <div class="bar">
                              <div class="title">ИЮЛ</div>
                              <div class="value tooltips" data-original-title="75%" data-toggle="tooltip" data-placement="top" style="height: 75%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">АВГ</div>
                              <div class="value tooltips" data-original-title="45%" data-toggle="tooltip" data-placement="top" style="height: 45%;"></div>
                          </div>
                          <div class="bar ">
                              <div class="title">СЕН</div>
                              <div class="value tooltips" data-original-title="50%" data-toggle="tooltip" data-placement="top" style="height: 50%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">ОКТ</div>
                              <div class="value tooltips" data-original-title="42%" data-toggle="tooltip" data-placement="top" style="height: 42%;"></div>
                          </div>
                          <div class="bar ">
                              <div class="title">НОЯ</div>
                              <div class="value tooltips" data-original-title="60%" data-toggle="tooltip" data-placement="top" style="height: 60%;"></div>
                          </div>
                          <div class="bar doted">
                              <div class="title">ДЕК</div>
                              <div class="value tooltips" data-original-title="90%" data-toggle="tooltip" data-placement="top" style="height: 90%;"></div>
                          </div>
                      </div>
                  </div>
              </div>
            
            
         
         
         
         

	</div>
	
	
<?php echo $footer;?>