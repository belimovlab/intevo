<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $title;?></title>
        <link rel="stylesheet" href="/css/style.css">
	<link rel="stylesheet" href="/css/fonts.css">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:700,400,600&amp;subset=latin,cyrillic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="/css/jquery.bxslider.css">
	<link rel="stylesheet" href="/css/jquery-ui.css">
	<link rel="stylesheet" href="/css/jquery.formstyler.css">
	<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
        <?php foreach($css as $one):?>
        <?php if($one):?>
        <link rel="stylesheet" href="/css/<?php echo $one;?>.css">
        <?php endif;?>
        <?php endforeach;?>
</head>
<body>
	<div class="wrapper">
            <div class="phone_menu">
                <div class="phone_menu_content">
                    <div class="phone_menu_content_title">обратная связь<span id="close_btn">X</span></div>
                    <div class="phone_menu_content_form">
                        <p>Заказать обратный звонок</p>
                        <form id="send_back_info" action="<?php echo base_url('kontakty/send_message')?>" method="POST">
                            <p>
                                <input type="text" name="name" id="name" class="back_form" placeholder="Ваше имя" required/> <input type="text" required name="email" id="email" class="back_form" placeholder="Телефон или Email"/>
                            </p>
                            <p>
                                
                            </p>
                            <p>
                                <textarea class="back_form_1" id="message" name="message" placeholder="Если у вас есть какие-то вопросы, напишите нам, и мы с вами свяжемся..."></textarea>
                            </p>
                            <p class="contacts">
                                <button href="#" class="btn-contacts" type="submit">Отправить сообщение</button>
                            </p>
                            <div style="clear: both;"></div>
                        </form>
                    </div>

                </div>
            </div>
		<div class="call-back-btn"></div>
		<div class="content">
			<header>
				<div class="container">
					<div class="logo">
                                            <a href="<?php echo base_url('/')?>"><img src="/img/logo.png" alt=""></a>
					</div>
					<div class="contacts">
						<div class="text-item">
							<a href="mailto:priem@dsk-omsk.ru">priem@dsk-omsk.ru</a>
							<p><span class="tel">+7 (3812) 56-04-41</span> <span>(телефон)</span></p>
							<p><span class="tel">+7 (3812) 56-04-31</span> <span>(факс)</span></p>
						</div>
						<a href="<?php echo base_url('/kontakty')?>" class="btn-contacts">Контакты</a>
					</div>
					<div class="clear"></div>
				</div>
			</header>
                    
                        <?php if($menu_active == 'main'):?>
                            <?php if(count($slider) > 0):?>
                                <div class="slider">
                                    <nav>
                                        <div class="container">
                                            <ul>
                                                <li><a href="<?php echo base_url('/')?>" class="active">Главная</a></li>
                                                <li><a href="<?php echo base_url('/about')?>">О компании</a></li>
                                                <li><a href="<?php echo base_url('/nedvizhimost')?>">Недвижимость</a></li>
                                                <li><a href="<?php echo base_url('/produkciya')?>">Продукция ЖБИ</a></li>
                                                <li><a href="<?php echo base_url('/tendery')?>">Тендеры</a></li>
                                                <li><a href="<?php echo base_url('/cariera')?>">Карьера</a></li>
                                            </ul>
                                        </div>
                                    </nav>
                                    <ul id="slider">
                                        <?php foreach($slider as $one):?>
                                            <li>
                                                <a href="<?php echo $one->link?>"><img src="<?php echo str_replace("../", "/", $one->url)?>" alt=""></a>
                                                    <div class="slider-content">
                                                        <p class="slider-title"><a href="<?php echo $one->link?>"><?php echo $one->stroka1?></a></p>
                                                        <p class="slider-description"><a href="<?php echo $one->link?>"><?php echo $one->stroka2?></a></p>
                                                        <p class="slider-date"><a href="<?php echo $one->link?>"><?php echo $one->stroka3?></a></p>
                                                    </div>
                                            </li>
                                        <?php endforeach;?>
                                    </ul>
                                </div>
                            <?php else:?>
                                <nav class="no-slider-nav">
                                    <div class="container">
                                        <ul>
                                            <li><a href="<?php echo base_url('/')?>" <?php echo $menu_active == 'about' ? 'class="active"' : '' ; ?>>Главная</a></li>
                                            <li><a href="<?php echo base_url('/about')?>" <?php echo $menu_active == 'about' ? 'class="active"' : '' ; ?>>О компании</a></li>
                                            <li><a href="<?php echo base_url('/nedvizhimost')?>" <?php echo $menu_active == 'nedvizhimost' ? 'class="active"' : '' ; ?>>Недвижимость</a></li>
                                            <li><a href="<?php echo base_url('/produkciya')?>" <?php echo $menu_active == 'produkciya' ? 'class="active"' : '' ; ?>>Продукция ЖБИ</a></li>
                                            <li><a href="<?php echo base_url('/tendery')?>" <?php echo $menu_active == 'tendery' ? 'class="active"' : '' ; ?>>Тендеры</a></li>
                                            <li><a href="<?php echo base_url('/cariera')?>" <?php echo $menu_active == 'cariera' ? 'class="active"' : '' ; ?>>Карьера</a></li>
                                        </ul>
                                    </div>
                                </nav>
                    
                            <?php endif;?>
                        
                        
                        <?php else:?>
                        <nav class="no-slider-nav">
				<div class="container">
					<ul>
                                            <li><a href="<?php echo base_url('/')?>">Главная</a></li>
                                            <li><a href="<?php echo base_url('/about')?>" <?php echo $menu_active == 'about' ? 'class="active"' : '' ; ?>>О компании</a></li>
                                            <li><a href="<?php echo base_url('/nedvizhimost')?>" <?php echo $menu_active == 'nedvizhimost' ? 'class="active"' : '' ; ?>>Недвижимость</a></li>
                                            <li><a href="<?php echo base_url('/produkciya')?>" <?php echo $menu_active == 'produkciya' ? 'class="active"' : '' ; ?>>Продукция ЖБИ</a></li>
                                            <li><a href="<?php echo base_url('/tendery')?>" <?php echo $menu_active == 'tendery' ? 'class="active"' : '' ; ?>>Тендеры</a></li>
                                            <li><a href="<?php echo base_url('/cariera')?>" <?php echo $menu_active == 'cariera' ? 'class="active"' : '' ; ?>>Карьера</a></li>
					</ul>
				</div>
			</nav>
                        <?php endif;?>
			



