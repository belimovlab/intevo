<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/goods/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Добавление категории
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/goods/save_type')?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <label for="page_title">Название категории</label>
                    <input type="text" class="form-control" id="category_name" placeholder="Название категории" name="category_name" value="">
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Добавить новую категорию</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>