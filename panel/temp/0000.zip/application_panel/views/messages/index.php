<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Список сообщений
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Дата</th>
                    <th>Сообщение</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($messages) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($messages as $one):?>
                        <tr>
                            <td><?php echo $one->view ? '<b>' : '';?><?php echo $i;?><?php echo $one->view ? '</b>' : '';?></td>
                            <td><?php echo $one->view ? '<b>' : '';?><?php echo date('d.m.Y',  strtotime($one->create_date))?><?php echo $one->view ? '</b>' : '';?></td>
                            <td><a  href="<?php echo base_url('/mail_inbox/view/'.$one->id)?>"><?php echo $one->view ? '<b>' : '';?><?php echo substr($one->text, 0, 100)."...";?><?php echo $one->view ? '</b>' : '';?></a></td>
                            <td>
                                <a  href="<?php echo base_url('/mail_inbox/delete/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="4" style="text-align: center;">У вас нет входящих сообщений.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
    
    
</div>
<?php echo $footer;?>