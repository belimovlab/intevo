$(document).ready(function() {
    
    function close_and_flush(){
        $('.phone_menu').css('display','none');
        $('#name').val('');
        $('#email').val('');
        $('#message').val('');
    }
    
    $('.call-back-btn').click(function(){
        $('.phone_menu').css('display','block');
    });
    $('#close_btn').click(function(){
        close_and_flush();
    });    
    $("#send_back_info").submit(function(e) {
        var url = "/kontakty/send_message";
        $.ajax({
               type: "POST",
               url: url,
               data: $("#send_back_info").serialize(),
               success: function(data)
               {
                   if(data=="1")
                   {
                        close_and_flush();
                   }
                   else

                   {
                       alert('Ваше сообщение отправить не удалось');
                   }
               }
             });
        e.preventDefault();
    });

    try{
        $(function() {
            $( "#slider-price-2" ).slider({
              range: true,
              min: 0.5,
              max: 10,
              values: [ 1, 10 ],
              slide: function( event, ui ) {
                $( ".amount_2" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
              }
            });
            $( ".amount_2" ).val( "" + $( "#slider-price-2" ).slider( "values", 0 ) +
              " - " + $( "#slider-price-2" ).slider( "values", 1 ) );
        });
    }catch(ex){}


});

$(document).ready(function() {
    $('#slider').bxSlider({
        speed: 800,
        auto: true,
        controls: false
    });
    
    $('#slider-house').bxSlider({
        speed: 800,
        auto: false,
       	pagerCustom: '#bx-pager'
			
    });
    
	
    $(function() {
            $( "#tabs" ).tabs();
    });
	
    $('input, select').styler();
	



});

$(function() {
    $( "#slider-price" ).slider({
      range: true,
      min: 0,
      max: 10,
      values: [ 1, 10 ],
      slide: function( event, ui ) {
        $( ".amount" ).val( "" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
      }
    });
    $( ".amount" ).val( "" + $( "#slider-price" ).slider( "values", 0 ) +
      " - " + $( "#slider-price" ).slider( "values", 1 ) );
  });





