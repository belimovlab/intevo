<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/parking/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/parking/update_object/'.$object->id)?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="house_name">Название жилого объекта <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_name" placeholder="Название жилого объекта" name="house_name" value="<?php echo $house_name ? htmlspecialchars($house_name) : '';?>">
                    </p>
                    <p>
                        <label for="house_start_build">Начало строительства <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_start_build" placeholder="Начало строительства" name="house_start_build" value="<?php echo $house_start_build ? htmlspecialchars($house_start_build) : '';?>">
                    </p>
                    <p>
                        <label for="house_end_build">Конец строительства <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_end_build" placeholder="Конец строительства" name="house_end_build" value="<?php echo $house_end_build ? htmlspecialchars($house_end_build) : '';?>">
                    </p>
                    <p>
                        <label for="house_square">Площадь жилого объекта <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_square" placeholder="Площадь жилого объекта" name="house_square" value="<?php echo $house_square ? htmlspecialchars($house_square) : '';?>">
                    </p>
                    <p>
                        <label for="house_floor">Этажность жилого объекта <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_floor" placeholder="Этажность жилого объекта" name="house_floor" value="<?php echo $house_floor ? htmlspecialchars($house_floor) : '';?>">
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Сохранить изменения</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>