/* 
 * Разработка Bepobox.ru
 * Связаться с авторами на сайте http://bepobox.ru
 */



$(document).ready(function(){

    var elems = document.getElementsByClassName('confirmation');
    var confirmIt = function (e) {
        if (!confirm('Вы уверены?')) e.preventDefault();
    };
    for (var i = 0, l = elems.length; i < l; i++) {
        elems[i].addEventListener('click', confirmIt, false);
    }
});
