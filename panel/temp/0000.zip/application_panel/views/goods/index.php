<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            
            <a href="<?php echo base_url('/goods/add_type')?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить категорию продукта</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Каталог продукции
            </header>
            <?php if($error):?>
            <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
            <?php endif;?>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Уникальный ID</th>
                    <th>Название</th>
                    <th>Операции</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($goods_catalog) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($goods_catalog as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo 'ART_'.$one->id;?></td>
                            <td><a href="<?php echo base_url('/goods/catalog/'.$one->id)?>"><?php echo $one->name?></a></td>
                            <td>
                                <a href="<?php echo base_url('/goods/edit_type/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a href="<?php echo base_url('/goods/photo/'.$one->id)?>" class="btn btn-warning btn-xs tooltips" data-original-title="Фотография" data-placement="bottom"><i class="icon-camera"></i></a>
                                <a href="<?php echo base_url('/goods/delete_type/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="6" style="text-align: center;">У вас нет каталогов продукции.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
</div>
<?php echo $footer;?>