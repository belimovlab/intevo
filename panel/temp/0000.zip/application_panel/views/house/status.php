<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/house/update_status/'.$object->id)?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="house_status">Статус работ над жилым объектом</label>
                        <input type="text" class="form-control" id="house_status" placeholder="Статус работ над жилым объектом" name="house_status" value="<?php echo $house_status ? htmlspecialchars($house_status) : '';?>">
                    </p>
                    <p>
                        <label for="house_percent">Процент выполненых работ <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_percent" placeholder="Процент выполненых работ" name="house_percent" value="<?php echo $house_percent ? htmlspecialchars($house_percent) : '';?>">
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Обновить информацию</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>