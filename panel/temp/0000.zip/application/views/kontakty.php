<?php echo $header;?>

<div class="production nedvizhimost carier">
    <div class="container">
        <div class="left-sidebar">
            <div class="menu-wrapper">
                <p class="left-sidebar-title no-icon-sidebar-title">Контакты</p>
                <ul class="sidebar-menu">
                    <?php foreach($top_news as $one):?>
                    <li><a href="<?php echo base_url('/about/view/'.$one->id)?>" class="active"><?php echo $one->title?></a></li>
                    <?php endforeach;?>
                </ul>
            </div>
        </div>
        <div class="right-block">
            <div class="broods">
                <ul>
                    <li><a href="<?php echo base_url('/')?>">Главная</a></li>
                    <li><a href="<?php echo base_url('/kontakty')?>">Контакты</a></li>
                </ul>
            </div>
            <div class="text">
                <div class="main_block">
                    <div class="left_main_block">
                        <?php echo $contacts;?>
                    </div>
                    <div class="right_main_block">
                        <?php if($error):?>
                        <p class="error"><?php echo $error;?></p>
                        
                        <?php endif;?>
                        <form action="<?php echo base_url('/kontakty/send_message')?>" method="POST">
                            <p>
                                <label for="name">Ваше Имя:</label>
                                <br/>
                                <input type="text" name="name" id="name" placeholder="Как к вам обращаться...">
                            </p>
                            <p>
                                <label for="email">Ваш телефон или Email:</label>
                                <br/>
                                <input type="text" name="email" id="email" placeholder="Как к вами связаться...">
                            </p>
                            <p>
                                <label for="email">Ваше сообщение :</label>
                                <br/>
                                <textarea name="message" style="height: 150px;"></textarea>
                            </p>
                            <p style="text-align: center; padding: 15px 0px; display: block; clear: both; margin-bottom: 20px;">
                                <button class="btn-contacts">Отправить сообщение</button>
                            </p>
                        </form>
                    </div>
                    
                </div>
                <p>&nbsp;</p>
                <p>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2291.288900358892!2d73.4418880158995!3d54.9504929803465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57514d1861bc587f!2z0JTQvtC80L7RgdGC0YDQvtC40YLQtdC70YzQvdGL0Lkg0LrQvtC80LHQuNC90LDRgg!5e0!3m2!1sru!2s!4v1448270901555" width="672" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </p>
            </div>
        </div>
    </div>



<?php echo $footer;?>