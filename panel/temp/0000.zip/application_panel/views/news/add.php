<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/news/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без добавления</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <header class="panel-heading tab-bg-dark-navy-blue ">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a data-toggle="tab" href="#home">Основные параметры</a>
                            </li>
                            <li class="">
                                <a data-toggle="tab" href="#seo">SEO-парамаетры</a>
                            </li>
                        </ul>
                    </header>
                    <form  action="<?php echo base_url('/news/save')?>" method="POST">
                    <div class="panel-body">
                        <?php if($error):?>
                            <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                        <?php endif;?>
                        <div class="tab-content">
                            <div id="home" class="tab-pane active">
                                <div class="form-group">
                                    <label for="page_title">Заголовок новости <span style="font-weight: lighter; font-size: 10px; color: red;">* Не более 100 символов включая пробелы.</span></label>
                                    <input type="text" class="form-control" id="page_title" placeholder="Заголовок новости" name="page_title" value="<?php echo $page_title ? htmlspecialchars($page_title): '';?>">
                                </div>
                                <div class="form-group">
                                    <label for="url">URL новости <span style="font-weight: lighter; font-size: 10px; color: red;">* Не меняйте это значение, если не понимаете для чего оно!</span></label>
                                    <input type="text" class="form-control" id="url" placeholder="URL новости" name="url" value="<?php echo $page_url ? htmlspecialchars($page_url): '';?>">
                                </div>
                                <div class="form-group">
                                    <label for="page_preview">Превью новости</label>
                                    <textarea id="page_preview" rows="6" name="preview"><?php echo $page_preview ? htmlspecialchars($page_preview): '';?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="page_content">Содержимое новости</label>
                                    <textarea id="page_content" rows="30" name="content"><?php echo $page_content ? htmlspecialchars($page_content): '';?></textarea>
                                </div>
                            </div>
                            <div id="seo" class="tab-pane">
                                <div class="form-group">
                                    <label for="keywords">META Keywords <span style="font-weight: lighter; font-size: 10px; color: red;">* Не меняйте это значение, если не понимаете для чего оно!</span></label>
                                    <input type="text" class="form-control" id="keywords" placeholder="META Keywords" name="keywords" value="<?php echo $meta_keywords ? htmlspecialchars($meta_keywords): '';?>">
                                </div>
                                <div class="form-group">
                                    <label for="description">META Description <span style="font-weight: lighter; font-size: 10px; color: red;">* Не меняйте это значение, если не понимаете для чего оно!</span></label>
                                    <input type="text" class="form-control" id="description" placeholder="META Description" name="description" value="<?php echo $meta_decsription ? htmlspecialchars($meta_decsription): '';?>">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-info"><i class="icon-save"></i> Созранить новость</button>
                    </form>
                    </div>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>