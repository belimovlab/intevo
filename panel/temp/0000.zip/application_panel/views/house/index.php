<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/add')?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить жилой объект</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Список жилых объектов
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Название жилого объекта</th>
                    <th>Начало строительства</th>
                    <th>Конец строительства</th>
                    <th>Площадь</th>
                    <th>Этажность</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($houses) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($houses as $one):?>
                        <tr>
                            <td><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $i;?></a></td>
                            <td><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $one->name?></a></td>
                            <td><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $one->start_build?></a></td>
                            <td><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $one->end_build?></a></td>
                            <td><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $one->square?></a></td>
                            <td style="text-align: center;"><a href="<?php echo base_url('/house/view/'.$one->id)?>"><?php echo $one->floor?></a></td>
                            <td>
                                <a  href="<?php echo base_url('/house/edit/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a  href="<?php echo base_url('/house/status/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Статус строительства" data-placement="bottom"><i class="icon-legal"></i></a>
                                <a  href="<?php echo base_url('/house/photo/'.$one->id)?>" class="btn btn-warning btn-xs tooltips" data-original-title="Фотографии" data-placement="bottom"><i class="icon-camera"></i></a>
                                <a  href="<?php echo base_url('/house/docs/'.$one->id)?>" class="btn btn-success btn-xs tooltips" data-original-title="Документация" data-placement="bottom"><i class="icon-file-text"></i></a>
                                <a  href="<?php echo base_url('/house/info/'.$one->id)?>" class="btn btn-info btn-xs tooltips" data-original-title="Информация" data-placement="bottom"><i class="icon-info"></i></a>
                                <a  href="<?php echo base_url('/house/delete/'.$one->id)?>" class="btn btn-danger btn-xs tooltips confirmation" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="7" style="text-align: center;">Вы пока не создали ни один жилой объект.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
        
</div>
<?php echo $footer;?>