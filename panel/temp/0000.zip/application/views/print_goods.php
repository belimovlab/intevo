<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
    <head>
        <title>Продукция / ДомоСтроительный Комбинат г.Омск</title>
        <meta name="content-language" content="ru" />
        <meta name="author" content="ДомоСтроительный Комбинат" />
        <meta name="keywords" content="строительство жилых домов, строительство котеджей, строительство офисов, железобетонные изделия, бетон" />
        <meta name="description" content="Строительство жилых домов, котеджей, офисов. Производство железобетонных изделий" />
        <meta name="robots" content="index, follow" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=1200px">
        <!--[if lt IE 9]>
        <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    <body>
	<table  align="center" style="font-size: 10pt; width: 600px;" rules="rows">
	<tr><td colspan="4"><b>ДомоСтроительный Комбинат (3812) 56-04-66 | 56-04-76</b></td></tr>
        <?php foreach( $arr_cat as $one):?>
            <tr bgcolor="e4e4e4">
                <td><b><?php echo $one->name?></b></td>
                <td>Вес</td>
                <td>V изд</td>
                <td>Цена с НДС (руб.)</td>
            </tr>
            <?php if(count($arr_goods[$one->id]) > 0):?>
                <?php foreach($arr_goods[$one->id] as $two):?>
                    <tr><td><?php echo $two->name?></td><td><?php echo $two->ves?></td><td><?php echo $two->objem?></td><td><?php echo $two->cost?></td></tr>
                <?php endforeach;?>
            <?php else:?>
                <tr><td colspan="4" style='text-align: center;'>Нет товаров в этой категории.</td></tr>
            <?php endif;?>
        <?php endforeach;?>
	</table>
    </body>
</html>	