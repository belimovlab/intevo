<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/goods/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <p style="text-align: center;">
      
                    
            <p style="text-align: center; padding: 10px;">Фотографии</p>
            <div class="block_content_photo">
                
                    <div class="one_photo">
                        <div class="one_photo_img">
                            <?php if($object->url1):?>
                                <img src="<?php echo str_replace("../","/", $object->url1)?>">
                            <?php else:?>
                                <p style="text-align: center; padding-top: 65px;"><a href="<?php echo base_url('/goods/add_photo/'.$object->id.'/1')?>">Загрузить</a></p>
                            <?php endif;?>
                        </div>
                        <div class="one_photo_delete">
                            <a href="<?php echo base_url('/goods/delete_photo/'.$object->id.'/1')?>">Удалить</a>
                        </div>
                    </div>
                    <div class="one_photo">
                       <div class="one_photo_img">
                            <?php if($object->url2):?>
                                <img src="<?php echo str_replace("../","/", $object->url2)?>">
                            <?php else:?>
                                <p style="text-align: center; padding-top: 65px;"><a href="<?php echo base_url('/goods/add_photo/'.$object->id.'/2')?>">Загрузить</a></p>
                            <?php endif;?>
                        </div>
                        <div class="one_photo_delete">
                            <a href="<?php echo base_url('/goods/delete_photo/'.$object->id.'/2')?>">Удалить</a>
                        </div>
                    </div>
                    <div class="one_photo">
                        <div class="one_photo_img">
                            <?php if($object->url3):?>
                                <img src="<?php echo str_replace("../","/", $object->url3)?>">
                            <?php else:?>
                                <p style="text-align: center; padding-top: 65px;"><a href="<?php echo base_url('/goods/add_photo/'.$object->id.'/3')?>">Загрузить</a></p>
                            <?php endif;?>
                        </div>
                        <div class="one_photo_delete">
                            <a href="<?php echo base_url('/goods/delete_photo/'.$object->id.'/3')?>">Удалить</a>
                        </div>
                    </div>
                
            </div>
            <div class="clearfix"></div>
  
            </p>
        </section>
    </div>
        
</div>
<?php echo $footer;?>