<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kontakty extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['header'] = $this->reload_header();
           $this->data['footer'] = $this->reload_footer();
       }



        public function index()
        {
            $this->data['contacts'] = $this->db->select('contacts')->get('more')->row()->contacts;
            $this->data['header'] = $this->reload_header('Контакты');
            $this->data['footer'] = $this->reload_footer();
            $this->data['error'] = $this->session->userdata('error');
            $this->session->unset_userdata('error');
            $this->load->view('kontakty',  $this->data);
        }
        
        
        public function send_message()
        {
            if(!$this->input->post('name')  || !$this->input->post('email') || !$this->input->post('message'))
            {
                $this->session->set_userdata('error','Заполните все поля!');
                redirect('/kontakty');
            }
            else
            {
                $this->db->insert('messages',array(
                    'create_date'=>date('Y-m-d H:i:s'),
                    'view'=>1,
                    'text'=> "Email: ".$this->input->post('email')."<br/><br/>Имя: ".$this->input->post('name')."<br/><br/> Сообщение: <br/><br/>".$this->input->post('message')
                ));
                
                if ( !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' )
                {
                       echo 1;
                }
                else
                {
                    redirect('/kontakty');
                }
            }

        }
       
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */