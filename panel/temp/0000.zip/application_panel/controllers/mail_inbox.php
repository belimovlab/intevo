<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mail_inbox extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 4;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['header'] = $this->reload_header('Список сообщений');
            $this->data['footer'] = $this->reload_footer();
            $this->data['messages'] = $this->db->order_by('id','desc')->get('messages')->result();
            $this->load->view('messages/index',  $this->data);
        }
        
        
        public function delete($id=0)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $this->db->delete('messages',array('id'=>$id));
                redirect('/mail_inbox/');
            }
            else
            {
                redirect('/mail_inbox/');
            }
        }
        
        
        public function view($id=0)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $this->data['message_info'] = $this->db->get_where('messages',array('id'=>$id))->row();
                if($this->data['message_info']->id)
                {
                    $this->db->update('messages',array('view'=>0),array('id'=>  $this->data['message_info']->id));
                    $this->data['new_messages'] > 0 ? $this->data['new_messages'] = $this->data['new_messages'] -1  : ''; 
                    $this->data['header'] = $this->reload_header('Просмотр сообщения','message_view');
                    $this->data['footer'] = $this->reload_footer();
                    $this->load->view('messages/view',  $this->data);
                }
                else
                {
                    redirect('/mail_inbox/');
                }
            }
            else
            {
                redirect('/mail_inbox/');
            }
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */