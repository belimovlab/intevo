<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/slider/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Добавление элемента
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/slider/save_item/')?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="name">Название элемента <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="name" placeholder="Название элемента" name="name" value="<?php echo $name ? htmlspecialchars($name) : '';?>">
                    </p>
                    <p>
                        <label for="link">Ссылка элемента </label>
                        <input type="text" class="form-control" id="link" placeholder="http://example.ru/" name="link" value="<?php echo $link ? htmlspecialchars($link) : '';?>">
                    </p>
                    
                    <p>
                        <label for="stroka1">Строка 1 </label>
                        <input type="text" class="form-control" id="stroka1" placeholder="" name="stroka1" value="<?php echo $stroka1 ? htmlspecialchars($stroka1) : '';?>">
                    </p>
                    
                    <p>
                        <label for="stroka2">Строка 2 </label>
                        <input type="text" class="form-control" id="stroka2" placeholder="" name="stroka2" value="<?php echo $stroka2 ? htmlspecialchars($stroka2) : '';?>">
                    </p>
                    
                    
                    <p>
                        <label for="stroka3">Строка 3 </label>
                        <input type="text" class="form-control" id="stroka3" placeholder="" name="stroka3" value="<?php echo $stroka3? htmlspecialchars($stroka3) : '';?>">
                    </p>
                    
                    
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Добавить новый элемент</button>
                    </form>
                </section>
             </div>
        </section>
    </div>
</div>
<?php echo $footer;?>