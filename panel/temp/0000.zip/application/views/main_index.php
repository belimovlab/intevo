<?php echo $header;?>

			

			<div class="cards-block">
				<div class="container">
					<div class="cards-item">
						<div class="image">
							<img src="/img/cards-image-1.jpg" alt="">
							<p class="cards-title">Продукция ЖБИ</p>
						</div>
						<ul>
                                                    <?php foreach($top_6 as $one):?>
                                                    <li><a href="<?php echo base_url('/produkciya/item/'.$one->id)?>"><?php echo $one->name?></a></li>
                                                    <?php endforeach;?>

						</ul>
						<div class="button-item">
							<a href="<?php echo base_url('/produkciya/')?>" class="btn-full-katalog"><span>Перейти в полный каталог</span></a>
						</div>
					</div>
					<div class="cards-item item-2">
						<div class="image">
                                                    <img src="/img/catalog_ned.png" alt="">
							<p class="cards-title">Недвижимость</p>
						</div>
						<ul>
							<li><a href="<?php echo base_url('/nedvizhimost/')?>">Жилая</a></li>
							<li><a href="<?php echo base_url('/nedvizhimost/parking')?>">Парк. места</a></li>
                                                        <li><a href="<?php echo base_url('/akcii')?>">Акции</a></li>
						</ul>
						<div class="button-item">
							<a href="<?php echo base_url('/nedvizhimost/')?>" class="btn-full-katalog"><span>Перейти в полный каталог</span></a>
						</div>
					</div>
				</div>
			</div>

			<div class="news">
				<div class="container">
					<div class="news-title">
						<h2>Новости</h2>
                                                <a href="<?php echo base_url('/news')?>" class="btn-arhive">к архиву новостей</a>
					</div>
					<div class="left-block">
                                            
                                            <?php if($top_news->image_url):?>
                                            <a href="<?php echo base_url('/news/'.$top_news->url)?>"><img src="<?php echo str_replace("../","/",$top_news->image_url)?>" alt=""></a>
                                            <?php endif;?>
                                            <p class="time"><?php echo date("d.m.Y H:i:s",  strtotime($top_news->create_date))?></p>
                                            <a href="<?php echo base_url('/news/'.$top_news->url)?>" class="text"><?php echo $top_news->title?></a>
					</div>
					<div class="right-block">
                                            
                                                <?php foreach($top_news_3 as $one):?>
						<div class="right-block-item">
                                                        <?php if($one->image_url):?>
							<a href="<?php echo base_url('/news/'.$one->url)?>"><img src="<?php echo str_replace("../","/",$one->image_url)?>" alt=""></a>
                                                        <?php endif;?>
							<p class="time"><?php echo date("d.m.Y H:i:s",  strtotime($top_news->create_date))?></p>
							<a href="<?php echo base_url('/news/'.$one->url)?>" class="text"><?php echo $one->title?></a>
						</div>
                                                <?php endforeach;?>

					</div>
				</div>
			</div>
<?php echo $footer;?>