
		</div>

		<footer>
			<div class="container">
				<div class="adres-item item-1">
					<p class="adres-title">Юридический адрес</p>
					<p class="adres">Россия, 644022, г. Омск, ул Ватутина 17</p>
				</div>
				<div class="adres-item item-2">
					<p class="adres-title">Почтовый адрес</p>
					<p class="adres">Россия, 644117, г. Омск, ул 3-я Молодежная 2</p>
				</div>
				<div class="social">
					<p>Мы в соцсетях</p>
					<a href="#" class="fb"></a>
					<a href="#" class="vk"></a>
				</div>
			</div>
		</footer>

	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="/js/jquery.bxslider.min.js"></script>
	<script src="/js/jquery-ui.min.js"></script>
	<script src="/js/jquery.formstyler.min.js"></script>
	<script src="/js/scripts.js"></script>

        <?php foreach($js as $one):?>
        <?php if($one):?>
        <script src="/js/<?php echo $one;?>.js"></script>
        <?php endif;?>
        <?php endforeach;?>

</body>

</html>