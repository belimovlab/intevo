<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
 * Разработка Bepobox.ru
 * Связаться с авторами на сайте http://bepobox.ru
 */



if (!function_exists('get_progress_bar'))
{
    function get_progress_bar($percent)
    {
        if($percent >0 && $percent <9)
            {
                return '/img/progress/progress-1.gif';
            }
            if($percent >9 && $percent <19)
            {
                return '/img/progress/progress-2.gif';
            }
            if($percent >19 && $percent <29)
            {
                return '/img/progress/progress-3.gif';
            }
            if($percent >29 && $percent <39)
            {
                return '/img/progress/progress-4.gif';
            }
            if($percent >39 && $percent <49)
            {
                return '/img/progress/progress-5.gif';
            }
            if($percent >49 && $percent <59)
            {
                return '/img/progress/progress-6.gif';
            }
            if($percent >59 && $percent <69)
            {
                return '/img/progress/progress-7.gif';
            }
            if($percent >69 && $percent <79)
            {
                return '/img/progress/progress-8.gif';
            }
            if($percent >79 && $percent <89)
            {
                return '/img/progress/progress-9.gif';
            }
            if($percent >89 && $percent <99)
            {
                return '/img/progress/progress-10.gif';
            }
            if($percent >99 )
            {
                return '/img/progress/progress-10.gif';
            }
    }
}
