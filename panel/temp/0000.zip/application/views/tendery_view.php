<?php echo $header;?>

<div class="production nedvizhimost carier">
				<div class="container">
					<div class="left-sidebar">
						<div class="menu-wrapper">
							<p class="left-sidebar-title no-icon-sidebar-title">Тендеры</p>
							<ul class="sidebar-menu">
                                                            <?php foreach($top_news as $one):?>
                                                            <li><a href="<?php echo base_url('/tendery/view/'.$one->id)?>" class="active"><?php echo $one->title?></a></li>
                                                            <?php endforeach;?>
							</ul>
						</div>
	

					</div>
					<div class="right-block">
						<div class="broods">
							<ul>
								<li><a href="<?php echo base_url('/')?>">Главная</a></li>
								<li><a href="<?php echo base_url('/tendery')?>">Тендеры</a></li>
							</ul>
						</div>
						<div class="text">
							<div class="right-block-title">
								<p><?php echo $page_info->title ? $page_info->title : 'Нет такой страницы';?></p>
							</div>
							<p>
                                                            <?php echo $page_info->content ? $page_info->content  : 'Страница по данному URL недоступна. Ее либо нет, либо она была удалена.';?>
                                                        </p>
                                                </div>
					</div>
				</div>



<?php echo $footer;?>