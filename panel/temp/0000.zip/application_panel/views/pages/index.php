<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/pages/add')?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Создать страницу</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Список созданных страниц
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Заголовок страницы</th>
                    <th>Категория страницы</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($pages) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($pages as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $one->title?></td>
                            <td>
                                <?php 
                                    switch($one->type_page)
                                    {
                                        default: 
                                            echo "Общая страница";
                                        break;
                                        case 2: 
                                            echo "Недвижиомсть";
                                        break;
                                        case 3: 
                                            echo "Вакансия";
                                        break;
                                        case 4: 
                                            echo "О компании";
                                        break;
                                        case 5: 
                                            echo "Тендеры";
                                        break;
                                        case 6: 
                                            echo "Акции";
                                        break;
                                     }
                                ?>
                            </td>
                            <td>
                                <button class="btn btn-success btn-xs tooltips get_url" data-original-title="Получить URL страницы" data-placement="bottom" data-page_url="<?php echo $one->id?>" data-url_link="<?php echo SITE_URL."page/".$one->url?>"><i class="icon-link"></i></button>
                                <a  href="<?php echo base_url('/pages/edit/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a  href="<?php echo base_url('/pages/delete/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Вы пока не создали ни одну страницу сайта.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
    
    <div class="show_message">
        <div class="message_content">
            <div class="close_link"><i class="icon-remove"></i> закрыть</div>
            <div class="message_content_link">
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    
</div>
<?php echo $footer;?>