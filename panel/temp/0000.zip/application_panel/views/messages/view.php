<?php echo $header;?>
<div class="row">
    
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/mail_inbox/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться к сообщениям</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Просмотр сообщения № <?php echo $message_info->id?> от <?php echo date('d.m.Y', strtotime($message_info->create_date));?>
            </header>
            <div class="panel-body word_wrap_needly">
                <?php echo $message_info->text?>
            </div>

        </section>
    </div>
    
    
</div>
<?php echo $footer;?>