<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/about/save_about/')?>" method="POST">
                    <?php if($success):?>
                        <p style="color: green; text-align: center; font-size: 12px;"><?php echo $success;?></p>
                    <?php endif;?>
                    <p>
                        <label for="more_about">Информация на главной странице</label>
                        <textarea type="text" id="more_about" name="more_about"><?php echo $more_about->about ? htmlspecialchars($more_about->about) : '';?></textarea>
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Сохранить информацию</button>
                    </form>
                </section>
             </div>
        </section>
    </div>
</div>
<?php echo $footer;?>