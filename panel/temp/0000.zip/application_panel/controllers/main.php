<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 1;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['header'] = $this->reload_header('Рабочий стол');
            $this->data['footer'] = $this->reload_footer();
            
            $this->data['house_cnt'] = $this->db->select('COUNT(id) as house_cnt')->get('house')->row()->house_cnt; 
            $this->data['flat_cnt'] = $this->db->select('COUNT(id) as flat_cnt')->get('house_flat')->row()->flat_cnt; 
            $this->data['goods_cnt'] = $this->db->select('COUNT(id) as goods_cnt')->get('goods')->row()->goods_cnt; 
            
            $this->data['pages'] = $this->db->limit(5)->order_by('id','desc')->get('pages')->result();
            
            
            
            $this->load->view('main',  $this->data);
        }
        
        
        public function update_flat()
        {
            $file = file('../flat.txt');
            foreach($file as $one)
            {
                $mas = explode("|", $one);
                $this->db->insert('house_flat',array(
                    'id'=>'',
                    'create_date'=>date('Y-m-d H:i:s'),
                    'etazh'=>$mas[1],
                    'nomer'=>$mas[0],
                    'square'=>$mas[2],
                    'cost'=>$mas[3],
                    'komnat'=>$mas[5],
                    'permetr'=>$mas[6],
                    'house_id'=>$mas[4]
                ));
            }
        }
        
        public function update_catalog()
        {
            $file = file('../flat.txt');
            foreach($file as $one)
            {
                
                $this->db->insert('goods_catalog',array(
                    'id'=>'',
                    'url'=>'',
                    'name'=>$one,
   
                ));
            }
        }
        
        public function update_goods()
        {
            $file = file('../flat.txt');
            foreach($file as $one)
            {
                $mas = explode("|", $one);
                $this->db->insert('goods',array(
                    'id'=>'',
                    'catalog_id'=>$mas[0],
                    'name'=>$mas[1],
                    'ves'=>$mas[2],
                    'objem'=>$mas[3],
                    'cost'=>$mas[4]
                ));
            }
        }
               
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */