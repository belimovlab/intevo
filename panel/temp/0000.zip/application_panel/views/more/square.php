<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/more/save_square/')?>" method="POST">
                    <?php if($success):?>
                        <p style="color: green; text-align: center; font-size: 12px;"><?php echo $success;?></p>
                    <?php endif;?>
                    <p>
                        <label for="more_square">Площадь постройки</label>
                        <input type="text" class="form-control" id="more_square" placeholder="" name="more_square" value="<?php echo $more_square->square ? htmlspecialchars($more_square->square) : '';?>">
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Добавить новый жилой объект</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>