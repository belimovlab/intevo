<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Produkciya extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['menu_active'] = 'produkciya';
       }



        public function index()
        {
            $this->data['header'] = $this->reload_header('Продукция ЖБИ');
            $this->data['footer'] = $this->reload_footer();
            $this->data['goods_catalog'] = $this->db->order_by('id','asc')->get('goods_catalog')->result();
            $this->data['goods'] = $this->db->get('goods')->result();
            $this->data['arr_goods'] = [];
            $this->data['arr_cat'] = [];
            foreach ($this->data['goods'] as $one)
            {
                $this->data['arr_goods'][$one->catalog_id][] = $one;
            }
            foreach($this->data['goods_catalog'] as $one)
            {
                $this->data['arr_cat'][$one->id] = $one; 
            }
            $this->load->view('produkciya',  $this->data);
        }
        
       
        public function print_goods()
        {
            $this->data['goods_catalog'] = $this->db->order_by('id','asc')->get('goods_catalog')->result();
            $this->data['goods'] = $this->db->get('goods')->result();
            $this->data['arr_goods'] = [];
            $this->data['arr_cat'] = [];
            foreach ($this->data['goods'] as $one)
            {
                $this->data['arr_goods'][$one->catalog_id][] = $one;
            }
            foreach($this->data['goods_catalog'] as $one)
            {
                $this->data['arr_cat'][$one->id] = $one; 
            }
            
            $this->load->view('print_goods',  $this->data);
        }
        
        
        public function item($id)
        {

            if($id && is_numeric($id))
            {
                $this->data['goods_catalog'] = $this->db->order_by('id','asc')->get('goods_catalog')->result();
                $this->data['catalog_info'] = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
                if($this->data['catalog_info']->id)
                {
                    $this->data['goods'] = $this->db->get_where('goods',array('catalog_id'=>  $this->data['catalog_info']->id))->result();
                    $this->data['header'] = $this->reload_header( $this->data['catalog_info']->name.' / Продукция ЖБИ');
                    $this->data['footer'] = $this->reload_footer();
                    $this->load->view('goods_item',  $this->data);
                }
                else
                {
                    redirect('/goods');
                }
            }
            else
            {
                redirect('/goods');
            }
        }
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */