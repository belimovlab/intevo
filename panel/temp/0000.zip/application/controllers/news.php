<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['header'] = $this->reload_header();
           $this->data['footer'] = $this->reload_footer();
       }



        public function index()
        {
            $url = $this->uri->segment(2);
            $url = urldecode($url);
            $this->data['page_info'] = $this->db->get_where('news',array('url'=>$url))->row();
            $this->data['top_news'] = $this->db->limit(10)->order_by('id','desc')->get('news')->result();
            $this->data['header'] = $this->reload_header($this->data['page_info']->title);
            $this->load->view('news_view',  $this->data);
        }
        
        
        public function show_all()
        {
            $url = $this->uri->segment(2);
            $url = urldecode($url);
            $this->data['page_info'] = $this->db->get_where('news',array('url'=>$url))->row();
            $this->data['top_news'] = $this->db->limit(10)->order_by('id','desc')->get('news')->result();
            $this->data['header'] = $this->reload_header($this->data['page_info']->title);
            $this->load->view('news_show_all',  $this->data);
        }
        
       
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */