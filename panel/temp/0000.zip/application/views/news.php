<?php echo $header;?>

			<div class="production">
				<div class="container">
					<div class="left-sidebar">
						<p class="left-sidebar-title">Новости сайта</p>
						<ul class="sidebar-menu">
                                                        <?php foreach($news as $one):?>
							<li><a href="<?php echo base_url('/news/'.$one->url)?>"><?php echo $one->title;?></a></li>
                                                        <?php endforeach;?>
	
						</ul>
					</div>
					<div class="right-block">

                                                
                                                
                                                <?php foreach( $arr_cat as $one):?>
                                                
                                                
                                                
                                                
                                                
						<div class="production-item">
							<p class="production-item-title">
								<?php echo $one->name;?>
							</p>
							<div class="production-item-content">
                                                                <?php if($one->url1):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url1)?>" alt="">
                                                                <?php endif;?>
								 <?php if($one->url2):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url2)?>" alt="">
                                                                <?php endif;?>
                                                                     <?php if($one->url3):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url3)?>" alt="">
                                                                <?php endif;?>

								<table>
									<tr class="table-title">
										<td class="col-name">Наименование изделия</td>
										<td class="col-ves">Вес</td>
										<td class="col-ves">V изд</td>
										<td>Цена издел. (НДС)</td>
									</tr>
                                                                        
                                                                        <?php foreach($arr_goods[$one->id] as $two):?>
									<tr>
                                                                                
										<td class="col-name"><?php echo $two->name?></td>
										<td class="col-ves"><?php echo $two->ves?></td>
										<td class="col-ves"><?php echo $two->objem?></td>
                                                                                <td class="col-price"><?php echo number_format($two->cost, 2, ".", " ");?></td>
									</tr>
                                                                        <?php endforeach;?>
									
								</table>
							</div>
						</div>
                                            
                                            
                                                <?php endforeach;?>
                                            
                                            
						

					</div>
				</div>
			</div>
<?php echo $footer;?>