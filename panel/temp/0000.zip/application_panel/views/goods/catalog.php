<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/goods/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться в каталог</a>
            <a href="<?php echo base_url('/goods/add_product/'.$catalog_info->id)?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить продукт</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $catalog_info->name?> / Каталог продукции
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#ID</th>
                    <th>Название</th>
                    <th>Объем</th>
                    <th>Вес</th>
                    <th>Цена</th>
                    <th>Операции</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($goods) > 0):?>
                    <?php foreach($goods as $one):?>
                        <tr>
                            <td><?php echo $one->id;?></td>
                            <td><?php echo $one->name;?></td>
                            <td><?php echo $one->objem;?></td>
                            <td><?php echo $one->ves;?></td>
                            <td><?php echo $one->cost;?></td>
                            <td>
                                <a href="<?php echo base_url('/goods/edit_good/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a href="<?php echo base_url('/goods/delete_good/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="6" style="text-align: center;">У вас нет продуктов.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
</div>
<?php echo $footer;?>