<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Настройка контактной информации
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/house/save_info_config/')?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                        <?php if($success):?>
                        <p style="color: green; text-align: center; font-size: 12px;"><?php echo $success;?></p>
                    <?php endif;?>
                    <p>
                        <label for="adres">Адрес офиса <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="adres" placeholder="Введите адрес офиса" name="adres" value="<?php echo $info->adres ? htmlspecialchars($info->adres) : '';?>">
                    </p>
                    <p>
                        <label for="email">Email <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="email" placeholder="Введите email" name="email" value="<?php echo $info->email ? htmlspecialchars($info->email) : '';?>">
                    </p>
                    <p>
                        <label for="phone">Телефон офиса <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="phone" placeholder="Введите телефон" name="phone" value="<?php echo $info->phone ? htmlspecialchars($info->phone) : '';?>">
                    </p>
                    <p>
                        <label for="fax">Факс офиса <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="fax" placeholder="Введите факс офиса" name="fax" value="<?php echo $info->fax ? htmlspecialchars($info->fax) : '';?>">
                    </p>

                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Сохранить данные</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>