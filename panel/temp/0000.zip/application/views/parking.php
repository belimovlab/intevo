<?php echo $header;?>

			<div class="production nedvizhimost">
				<div class="container">
					<div class="left-sidebar">
						<div class="menu-wrapper">
							<p class="left-sidebar-title no-icon-sidebar-title">Тип недвижимости</p>
							<ul class="sidebar-menu">
                                                            <li><a href="<?php echo base_url('/nedvizhimost')?>">Жилая</a></li>
                                                            <li><a href="<?php echo base_url('/parking')?>" class="active">Парковочные места</a></li>
							</ul>
						</div>
						<div class="office-title">Офис продаж</div>
						<div class="office-contacts">
							<p class="adres"><?php echo $office_info->adres;?></p>
							<p class="tel"><span><?php echo $office_info->phone;?></span></p>
							<p class="fax"><?php echo $office_info->fax;?></p>
							<a class="mail" href="mailto:<?php echo $office_info->email;?>"><?php echo $office_info->email;?></a>
						</div>
						<div class="banner">
							<img src="/img/banner_4.png" alt="">
						</div>
                                                <?php foreach($top_3_ned as $one):?>
                                                
						<div class="news-item">
                                                    <a href="<?php echo base_url('/pages/'.$one->url)?>"><?php echo $one->title?></a>
                                                    <p><?php echo $one->content; ?></p>
						</div>
                                                <?php endforeach;?>
					
					</div>
					<div class="right-block">
						<div class="broods">
							<ul>
								<li><a href="<?php echo base_url('/')?>">Главная</a></li>
								<li><a href="<?php echo base_url('/nedvizhimost')?>">Недвижимость</a></li>
							</ul>
						</div>
						<p class="right-block-title">Поиск</p>
						<div id="tabs">
							<ul>
								<li><a href="#tabs-2"><span>Парковочне места</span></a></li>
							</ul>
	
                                                    <div id="tabs-2"> 
                                                        <form action="<?php echo base_url('/parking/search/')?>"  method="get"> 
                                                            <div class="select-item"> 
                                                                <span class="title">Дом:</span> 
                                                                <select name="house"> 
                                                                    <?php foreach($houses as $one):?> 
                                                                        <option value="<?php echo $one->id?>"><?php echo $one->name?></option> 
                                                                    <?php endforeach;?> 
                                                                </select> 
                                                            </div> 
                                                            <div class="slider-item"> 
                                                                <span>Цена:</span> 
                                                                <div id="slider-price-2"> 
                                                                    <p> 
                                                                        <input type="text" class="amount_2" readonly name="cost"> 
                                                                    </p> 
                                                                </div> 
                                                                <span>млн. руб</span> 
                                                            </div> 
                                                            <input class="search-btn" type="submit" value="Найти"> 
                                                            <div class="clear"></div> 
                                                        </form> 
                                                    </div>

						</div>

						<p class="search-result"><span>Найдено <?php echo count($houses);?> объект(а)</span></p>

                                                <?php foreach($houses as $one):?>
                                                
						<div class="result-item">
                                                        <div class="photo"><a href="<?php echo base_url('/parking/view/'.$one->id)?>"><img src="<?php echo $one->main_photo?>" alt=""></a></div>
							<div class="description-wrap">
								<p class="result-title"><?php echo $one->name;?></p>
								<div class="table">
                                                                    <table style="width: 626px;">
										<tr>
											<td>Этажей</td>
											<td><?php echo $one->floor?></td>
										</tr>
										<tr class="tr-bold">
											<td>Паркингов в продаже</td>
											<td><?php echo count($flat_new[$one->id]) > 0 ? count($flat_new[$one->id])-2 : 'Нет парковочных мест';?></td>
										</tr>

										<tr class="tr-price">
											<td>цена </td>
                                                                                        <td><?php echo number_format($flat_new[$one->id]['min_cost'], 0, "", " ");?> - <?php echo number_format($flat_new[$one->id]['max_cost'], 0, "", " ");?>  руб</td>
										</tr>
									</table>
								</div>

							</div>
						</div>
                                                <?php endforeach;?>
					</div>
				</div>
			</div>
<?php echo $footer;