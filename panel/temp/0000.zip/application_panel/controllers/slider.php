<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Slider extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 11;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['header'] = $this->reload_header('Элементы слайдера');
            $this->data['footer'] = $this->reload_footer();
            $this->data['slider'] = $this->db->order_by('id','desc')->get('slider')->result();
            $this->load->view('slider/index',  $this->data);
        }
        

        public function add_item()
        {
            $this->data['header'] = $this->reload_header('Добавление элемента');
            $this->data['footer'] = $this->reload_footer();
            $this->data['name'] = $this->session->userdata('name');
            $this->data['link'] = $this->session->userdata('link');
            $this->data['error'] = $this->session->userdata('error');
            $this->session->unset_userdata('name');
            $this->session->unset_userdata('link');
            $this->session->unset_userdata('error');
            $this->load->view('slider/add_item',  $this->data);
        }
        
        
        public function save_item()
        {
            if($this->input->post('name') && $this->input->post('link'))
            {
                $this->db->insert('slider',array(
                    'name'=>  $this->input->post('name'),
                    'link'=>  $this->input->post('link'),
                    'stroka1'=>  $this->input->post('stroka1'),
                    'stroka2'=>  $this->input->post('stroka2'),
                    'stroka3'=>  $this->input->post('stroka3'),
                ));
                $this->session->unset_userdata('name');
                $this->session->unset_userdata('link');
                $this->session->unset_userdata('error');
                redirect('/slider');
            }
            else
            {
                $this->session->set_userdata('name',$this->input->post('name'));
                $this->session->set_userdata('link',$this->input->post('link'));
                $this->session->set_userdata('error','Заполните все поля.');
                redirect('/slider/add_item');
            }
        }
        
        
        public function add_photo($id)
        {
            $this->data['elem_info'] = $this->db->get_where('slider',array('id'=>$id))->row();
            if($this->data['elem_info']->id)
            {
                $this->data['header'] = $this->reload_header('Добавление изображения к элементу');
                $this->data['footer'] = $this->reload_footer();
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata('error');
                $this->load->view('slider/add_photo',  $this->data);
            }
            else
            {
                redirect('/slider');
            }
        }
        
        private function rus2translit($string) {
            $converter = array(
                'а' => 'a',   'б' => 'b',   'в' => 'v',
                'г' => 'g',   'д' => 'd',   'е' => 'e',
                'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
                'и' => 'i',   'й' => 'y',   'к' => 'k',
                'л' => 'l',   'м' => 'm',   'н' => 'n',
                'о' => 'o',   'п' => 'p',   'р' => 'r',
                'с' => 's',   'т' => 't',   'у' => 'u',
                'ф' => 'f',   'х' => 'h',   'ц' => 'c',
                'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
                'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
                'э' => 'e',   'ю' => 'yu',  'я' => 'ya',

                'А' => 'A',   'Б' => 'B',   'В' => 'V',
                'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
                'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
                'И' => 'I',   'Й' => 'Y',   'К' => 'K',
                'Л' => 'L',   'М' => 'M',   'Н' => 'N',
                'О' => 'O',   'П' => 'P',   'Р' => 'R',
                'С' => 'S',   'Т' => 'T',   'У' => 'U',
                'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
                'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
                'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
                'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
            );
            return strtr($string, $converter);
        }
        private function str2url($str) {
            $str = $this->rus2translit($str);
            $str = strtolower($str);
            $str = preg_replace('~[^-a-z0-9_]+~u', '_', $str);
            $str = trim($str, "-");
            return $str;
        }
        
        public function save_item_photo($id)
        {
            $object = $this->db->get_where('slider',array('id'=>$id))->row();
            if($object->id)
            {
                    $file_extension = end((explode(".", $_FILES['house_file']['name'])));
                    $allowed_extension = array('jpg','png','gif','jpeg');
                    if(in_array($file_extension, $allowed_extension))
                    {
                        $path_to_upload = "../upload_files/photos/";
                        $uploadfile = $path_to_upload. $this->str2url( basename($_FILES['house_file']['name']));
                        $uploadfile_1 = $uploadfile.'.'.$file_extension;
                        if (move_uploaded_file($_FILES['house_file']['tmp_name'], $uploadfile_1)) {
                            include '../simpleimage.php';
                            $img = new SimpleImage($uploadfile_1);
                            $img->resize(1200, 517);
                            $small = $uploadfile."_slider.".$file_extension;
                            $img->save($small);
                            unlink($uploadfile_1);
                            $this->db->update('slider',array('url'=>$small),array('id'=>$object->id));
                            redirect('/slider/');
                            
                        } else {
                            $this->session->set_userdata('error','Файл не был загружен. Попробуйте еще раз.');
                            redirect('/slider/add_photo/'.$object->id);
                        }
                    }
                    else
                    {
                        $this->session->set_userdata('error','Выберите файл, который соответствует параметрам.');
                        redirect('/slider/add_photo/'.$object->id);
                    }
            }
            else
            {
                redirect('/slider');
            }
        }
       
        
        public function delete_item($id)
        {
            $object = $this->db->get_where('slider',array('id'=>$id))->row();
            if($object->id)
            {
                if($object->url)
                {
                    unlink($object->url);
                }
                $this->db->delete('slider',array('id'=>$id));
                redirect('/slider/');
            }
            else
            {
                redirect('/slider');
            }
        }
       
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */