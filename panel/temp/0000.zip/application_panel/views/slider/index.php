<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            
            <a href="<?php echo base_url('/slider/add_item')?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить новый элемент в слайдер</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Список элементов слайдера
            </header>
            <?php if($error):?>
            <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
            <?php endif;?>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Название</th>
                    <th>Превью</th>
                    <th>Операции</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($slider) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($slider as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $one->name?></td>
                            <td>
                                <?php if($one->url):?>
                                <img src="<?php echo str_replace("../", "/", $one->url)?>" height="50">
                                <?php else:?>
                                    -
                                <?php endif;?>
                            </td>
                            <td>
                                <a href="<?php echo base_url('/slider/add_photo/'.$one->id)?>" class="btn btn-warning btn-xs tooltips" data-original-title="Фотография" data-placement="bottom"><i class="icon-camera"></i></a>
                                <a href="<?php echo base_url('/slider/delete_item/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="6" style="text-align: center;">У вас нет элементов в слайдере.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
</div>
<?php echo $footer;?>