<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/news/')?>" class="btn btn-shadow btn-primary"><i class="icon-arrow-left"></i> Вернуться к списку новостей</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Фотография к новости
            </header>
            <div class="center_image">
                <?php if($one_page->image_url):?>
                <img src="<?php echo str_replace("../", "/", $one_page->image_url)?>">
                <?php else:?>
                <a href="<?php echo base_url('/news/add_photo/'.$one_page->id)?>">Загрузить фотографию...</a>
                <?php endif;?>
            </div>
            <?php if($one_page->image_url):?>
                <p style="text-align: center;"><a href="<?php echo base_url('/news/delete_photo/'.$one_page->id)?>">Удалить</a></p>
            <?php endif;?>
                <br/><br/>
            <div class="clearfix"></div>
        </section>
    </div>
</div>
<?php echo $footer;?>