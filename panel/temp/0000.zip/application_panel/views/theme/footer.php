          </section>
      </section>
  </section>

  
  <script src="/panel_assets/js/jquery.js"></script>
  <script src="/panel_assets/js/bootstrap.min.js"></script>
  <script src="/panel_assets/js/jquery.scrollTo.min.js"></script>
  <script src="/panel_assets/js/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="/panel_assets/js/common-scripts.js"></script>
  
  <?php foreach($js as $one):?>
    <?php if($one):?>
        <script src="/panel_assets/js/<?php echo $one;?>.js"></script>
    <?php endif;?>
  <?php endforeach;?>
  </body>
</html>
