<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться</a>
            <a href="<?php echo base_url('/house/add_docs/'.$object->id)?>" class="btn btn-shadow btn-success"><i class="icon-plus"></i> Загрузить новый документ</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Название документа</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($house_docs) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($house_docs as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><i class="icon-file-text fa-file-<?php echo $one->extension;?>"></i> <?php echo $one->name?></td>
                            <td>
                                <a  href="<?php echo base_url('/house/delete_docs/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="3" style="text-align: center;">Вы пока не загрузили ни один документ.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
        
</div>
<?php echo $footer;?>