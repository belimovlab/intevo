<?php echo $header;?>

			<div class="production nedvizhimost">
				<div class="container">
					<div class="dom-main-content">
						<div class="broods">
							<ul>
                                                            <li><a href="<?php echo base_url('/')?>">Главная</a></li>
                                                            <li><a href="<?php echo base_url('/nedvizhimost')?>">Недвижимость</a></li>
                                                            <li><a href="<?php echo base_url('/nedvizhimos/view/'.$house_info->id)?>"><?php echo $house_info->name?></a></li>
							</ul>
						</div>
						<div class="house-item">
							<p class="house-title"><?php echo $house_info->name?></p>

							<ul class="bxslider" id="slider-house">
                                                                <?php foreach($house_photo as $one):?>
                                                                <li><img src="<?php echo str_replace("../", "/", $one->url_big)?>" alt="" width="940" height="524"></li>
                                                                <?php endforeach;?>
							</ul>
							<div id="bx-pager">
                                                                <?php $i=0;?>
                                                                <?php foreach($house_photo as $one):?>
                                                                <a data-slide-index="<?php echo $i;?>" href=""><img src="<?php echo str_replace("../", "/", $one->url_small)?>" alt="" width="187" height="105"></a>
                                                                <?php $i++;?>
                                                                <?php endforeach;?>
							</div>
							<div class="description-wrap" style="width: 940px">
								<div class="table">
									<table>
										<tr>
											<td>Этажей</td>
											<td><?php echo $house_info->floor?></td>
										</tr>
										<tr>
											<td>S квартир</td>
											<td><?php echo $house_info->square?> М2</td>
										</tr>
										<tr class="tr-bold">
											<td>квартир в продаже</td>
											<td><?php echo count($house_flat)?></td>
										</tr>
										<tr class="tr-bold">
											<td>срок сдачи объекта</td>
											<td><?php echo $house_info->end_building?></td>
										</tr>
										<tr class="tr-price">
											<td>цена </td>
											<td><?php echo number_format($min_cost, 0, "", " ");?> - <?php echo number_format($max_cost, 0, "", " ");?> руб</td>
										</tr>
									</table>
								</div>
								<div class="preim">
									<ul>
										<li class="item-1">Экологичность</li>
										<li class="item-2">Доступность</li>
										<li class="item-3">Детсад</li>
										<li class="item-4">школа</li>
										<li class="item-5">парк</li>
										<li class="item-6">инфраструктура</li>
									</ul>
								</div>
							</div>
                                                        
                                                        <div class="house-price-table">
                                                            <table style="width: 940px">
									<tr>
										<td>Документация к жилому объекту</td>
									</tr>
                                                                        <?php foreach($house_docs as $one):?>
                                                                        
									<tr>
                                                                            <td style="text-align: left;"><span><a class="download_link" href="<?php echo str_replace("../","/",$one->url)?>" target="_blank"><?php echo $one->name?></a></span>-скачать</td>
	
									</tr>
                                                                        <?php endforeach;?>
									
								</table>
							</div>
                                                        
							<div class="house-price-table">
								<table style="width: 940px">
									<tr>
										<td>Вид квартиры</td>
										<td>№ квартиры</td>
										<td>площадь</td>
										<td>этаж</td>
										<td>цена за м&#178;</td>
										<td>статус</td>
										<td>общая цена</td>
									</tr>
                                                                        <?php foreach($house_flat as $one):?>
                                                                        
									<tr>
										<td><span><?php echo $one->komnat?></span>-комнатная</td>
										<td><?php echo $one->nomer?></td>
										<td><span><?php echo $one->square?></span></td>
										<td><span><?php echo $one->etazh?></span>/<?php echo $house_info->floor?></td>
                                                                                <td><?php echo number_format($one->permetr, 0, "", " ")?></td>
										<td class="status">в продаже</td>
										<td class="price"><span><?php echo number_format($one->cost,0,""," ");?></span></td>
									</tr>
                                                                        <?php endforeach;?>
									
								</table>
							</div>
						</div>
					</div>
				</div>

<?php echo $footer;