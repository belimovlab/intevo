<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/more/save_info/')?>" method="POST">
                    <?php if($success):?>
                        <p style="color: green; text-align: center; font-size: 12px;"><?php echo $success;?></p>
                    <?php endif;?>
                    <p>
                        <label for="more_info">Информация на главной странице</label>
                        <textarea type="text" id="more_info" name="more_info"><?php echo $more_info->info ? htmlspecialchars($more_info->info) : '';?></textarea>
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Сохранить информацию</button>
                    </form>
                </section>
             </div>
        </section>
    </div>
</div>
<?php echo $footer;?>