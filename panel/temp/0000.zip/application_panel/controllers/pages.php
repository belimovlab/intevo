<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PAges extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 2;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['sub_menu_active'] = 'pages';
            $this->data['header'] = $this->reload_header('Список страниц','show_message');
            $this->data['footer'] = $this->reload_footer('get_url');
            
            $this->data['pages'] = $this->db->order_by('id','desc')->get('pages')->result();
            $this->load->view('pages/index',  $this->data);
        }
        
        
        public function add()
        {
            $this->data['sub_menu_active'] = 'pages/add';
            $this->data['header'] = $this->reload_header('Список страниц');
            $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
            $this->data['error'] = $this->session->userdata('error');
            $this->data['page_title'] = $this->session->userdata('page_title');
            $this->data['page_url'] = $this->session->userdata('page_url');
            $this->data['page_content'] = $this->session->userdata('page_content');
            $this->data['meta_keywords'] = $this->session->userdata('meta_keywords');
            $this->data['meta_decsription'] = $this->session->userdata('meta_decsription');
            $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
            $this->data['pages'] = $this->db->order_by('id','desc')->get('pages')->result();
            $this->load->view('pages/add',  $this->data);
        }
        
        
        public function save()
        {
            $this->input->post('page_title')  ?  $this->session->set_userdata('page_title', $this->input->post('page_title'))  :  '';
            $this->input->post('content')  ?  $this->session->set_userdata('page_content', $this->input->post('content'))  :  '';
            $this->input->post('keywords')  ?  $this->session->set_userdata('meta_keywords', $this->input->post('keywords'))  :  '';
            $this->input->post('description')  ?  $this->session->set_userdata('meta_decsription', $this->input->post('description'))  :  '';
            $this->input->post('url')  ?  $this->session->set_userdata('page_url', $this->input->post('url'))  :  '';
            if(!$this->input->post('page_title') || !$this->input->post('url'))
            {
                $this->session->set_userdata('error','Заполните название страницы или ее URL.');
                redirect('/pages/add');
            }
            else
            {
                
                $res = $this->db->get_where('pages',array('url'=>  $this->input->post('url')))->row();
                if($res->id)
                {
                    $this->session->set_userdata('error','Такой URL уже есть. Поменяйте URL.');
                    redirect('/pages/add');
                }
                else
                {

                    $this->db->insert('pages',array(
                        'id'=>'',
                        'create_date'=>date('Y-m-d H:i:s'),
                        'title'=>  $this->input->post('page_title'),
                        'url'=>  $this->input->post('url'),
                        'description'=>  $this->input->post('description'),
                        'keywords'=>  $this->input->post('keywords'),
                        'content'=>  $this->input->post('content'),
                        'visible'=>  1,
                        'type_page'=> $this->input->post('type_page') ? $this->input->post('type_page') : 1
                    ));
                    $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
                    redirect('/pages');

                }
            }
            
            
            
        }

        
        function delete($id=0)
        {
            if($id && $id> 0 && is_numeric($id))
            {
                $this->db->delete('pages', array('id'=>$id));
                redirect('/pages');
            }
            else
            {
                redirect('/pages');
            }
        }
               
        
        
        function edit($id=0)
        {
            if($id && $id> 0 && is_numeric($id))
            {
                $one_page  = $this->db->get_where('pages',array('id'=>$id))->row();
                if($one_page->id)
                {
                    $this->data['header'] = $this->reload_header('Редактирование страницы');
                    $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
                    $this->data['error'] = $this->session->userdata('error');
                    $this->data['page_title'] = $this->session->userdata('page_title');
                    $this->data['page_url'] = $this->session->userdata('page_url');
                    $this->data['page_content'] = $this->session->userdata('page_content');
                    $this->data['meta_keywords'] = $this->session->userdata('meta_keywords');
                    $this->data['meta_decsription'] = $this->session->userdata('meta_decsription');
                    $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
                    $this->data['one_page'] = $one_page;
                    $this->load->view('pages/edit',  $this->data);
                }
                else
                {
                    redirect('/pages');
                }
                
                

            }
            else
            {
                redirect('/pages');
            }
        }
        
        
        public function save_edit()
        {
            $page_id = $this->input->post('page_id');
            $this->input->post('page_title')  ?  $this->session->set_userdata('page_title', $this->input->post('page_title'))  :  '';
            $this->input->post('content')  ?  $this->session->set_userdata('page_content', $this->input->post('content'))  :  '';
            $this->input->post('keywords')  ?  $this->session->set_userdata('meta_keywords', $this->input->post('keywords'))  :  '';
            $this->input->post('description')  ?  $this->session->set_userdata('meta_decsription', $this->input->post('description'))  :  '';
            $this->input->post('url')  ?  $this->session->set_userdata('page_url', $this->input->post('url'))  :  '';
            if(!$this->input->post('page_title') || !$this->input->post('url'))
            {
                $this->session->set_userdata('error','Заполните название страницы или ее URL.');
                redirect('/pages/edit/'.$page_id);
            }
            else
            {
                
                $res = $this->db->get_where('pages',array('url'=>  $this->input->post('url')))->row();
                if($res->id && $res->id != $page_id)
                {
                    $this->session->set_userdata('error','Такой URL уже есть. Поменяйте URL.');
                    redirect('/pages/edit/'.$page_id);
                }
                else
                {
                    $this->db->update('pages',array(
                        'create_date'=>date('Y-m-d H:i:s'),
                        'title'=>  $this->input->post('page_title'),
                        'url'=>  $this->input->post('url'),
                        'description'=>  $this->input->post('description'),
                        'keywords'=>  $this->input->post('keywords'),
                        'content'=>  $this->input->post('content'),
                        'type_page'=> $this->input->post('type_page') ? $this->input->post('type_page') : 1
                    ),array(
                        'id'=>$page_id
                    ));
                    $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
                    redirect('/pages');
                }
            }
            
            
            
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */