<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/goods/catalog/'.$cat_id)?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Добавление продукта
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/goods/save_product/'.$cat_id)?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="page_title">Название продукта <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="category_name" placeholder="Название продукта" name="product_name" value="<?php echo $product_name ? htmlspecialchars($product_name) : '';?>">
                    </p>
                    <p>
                        <label for="product_objem">Объем продукта</label>
                        <input type="text" class="form-control" id="product_objem" placeholder="" name="product_objem" value="<?php echo $product_objem ? htmlspecialchars($product_objem) : '';?>">
                    </p>
                    <p>
                        <label for="product_ves">Вес продукта</label>
                        <input type="text" class="form-control" id="product_ves" placeholder="" name="product_ves" value="<?php echo $product_ves ? htmlspecialchars($product_ves) : '';?>">
                    </p>
                    <p>
                        <label for="product_cost">Цена продукта <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="product_cost" placeholder="" name="product_cost" value="<?php echo $product_cost ? htmlspecialchars($product_cost) : '';?>">
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Добавить новый продукт</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>