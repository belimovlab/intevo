<?php echo $header;?>

			<div class="production">
				<div class="container">
					<div class="left-sidebar">
						<p class="left-sidebar-title">Продукция ЖБИ</p>
						<ul class="sidebar-menu">
                                                    <li><a href="<?php echo base_url('/produkciya')?>">Вся продукция</a></li>
                                                        <?php foreach($goods_catalog as $one):?>
							<li><a href="<?php echo base_url('/produkciya/item/'.$one->id)?>" <?php echo  $one->id == $catalog_info->id? ' class="active"' : '' ; ?>><?php echo $one->name;?></a></li>
                                                        <?php endforeach;?>
                                                        <li><a href="/produkciya/print_goods">Версия для печати</a></li>
	
						</ul>
					</div>
					<div class="right-block">
						<div class="broods">
							<ul>
                                                            <li><a href="<?php echo base_url('/')?>">Главная</a></li>
                                                            <li><a href="<?php echo base_url('/produkciya')?>">Продукция ЖБИ</a></li>
                                                            <li><a href="<?php echo base_url('/produkciya/item/'.$catalog_info->id)?>"><?php echo $catalog_info->name?></a></li>                                                              
							</ul>
						</div>
                                                
                                                
                                                <?php $one = $catalog_info;?>
                                                
                                                
                                                
                                                
                                                
						<div class="production-item">
							<p class="production-item-title">
								<?php echo $one->name;?>
							</p>
							<div class="production-item-content">
                                                                <?php if($one->url1):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url1)?>" alt="">
                                                                <?php endif;?>
								 <?php if($one->url2):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url2)?>" alt="">
                                                                <?php endif;?>
                                                                     <?php if($one->url3):?>
                                                                    <img src="<?php echo str_replace("../", "/", $one->url3)?>" alt="">
                                                                <?php endif;?>

								<table>
									<tr class="table-title">
										<td class="col-name">Наименование изделия</td>
										<td class="col-ves">Вес</td>
										<td class="col-ves">V изд</td>
										<td>Цена издел. (НДС)</td>
									</tr>
                                                                        
                                                                        <?php foreach($goods as $two):?>
									<tr>
                                                                                
										<td class="col-name"><?php echo $two->name?></td>
										<td class="col-ves"><?php echo $two->ves?></td>
										<td class="col-ves"><?php echo $two->objem?></td>
                                                                                <td class="col-price"><?php echo number_format($two->cost, 2, ".", " ");?></td>
									</tr>
                                                                        <?php endforeach;?>
									
								</table>
							</div>
						</div>
                                            
                                            

                                            
                                            
						

					</div>
				</div>
			</div>
<?php echo $footer;