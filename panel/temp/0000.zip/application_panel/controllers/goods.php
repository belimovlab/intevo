<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Goods extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 6;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['sub_menu_active'] = 'pages';
            $this->data['header'] = $this->reload_header('Каталог продукции');
            $this->data['footer'] = $this->reload_footer();
            $this->data['goods_catalog'] = $this->db->order_by('id','asc')->get('goods_catalog')->result();
            $this->data['error'] = $this->session->userdata('error');
            $this->session->unset_userdata('error');
            $this->load->view('goods/index',  $this->data);
        }
        
        
        public function catalog($id=0)
        {
            if($id && $id > 0)
            {
                $this->data['catalog_info'] = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
                if($this->data['catalog_info']->id)
                {
                    $this->data['sub_menu_active'] = 'pages';
                    $this->data['header'] = $this->reload_header($this->data['catalog_info']->name.' / Каталог продукции');
                    $this->data['footer'] = $this->reload_footer();
                    $this->data['goods'] = $this->db->order_by('id','asc')->get_where('goods',array('catalog_id'=>$this->data['catalog_info']->id))->result();
                    $this->data['error'] = $this->session->userdata('error');
                    $this->load->view('goods/catalog',  $this->data);
                }
                else
                {
                    redirect('/goods');
                }
            }
            else
            {
                redirect('/goods');
            }
        }
        
        
        
        
        
        public function add_type()
        {
                $this->data['header'] = $this->reload_header('Добавить категорию');
                $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
                $this->data['error'] = $this->session->userdata('error');
                $this->load->view('goods/add_type',  $this->data);
            
        }

        
        public function save_type()
        {
            if($this->input->post('category_name'))
            {
                $this->db->insert('goods_catalog',array(
                    'id'=>'',
                    'name'=>  $this->input->post('category_name')
                ));
                redirect('/goods');
            }
            else
            {
                $this->session->set_userdata('error','Введите название категории.');
                redirect('/goods/add_type');
            }
        }


        public function delete_type($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods',array('catalog_id'=>$id))->result();
                if(count($res) > 0 )
                {
                    $this->session->set_userdata('error','Каталог не пустой! Удалите сначала продукцию из каталога!');
                    redirect('/goods/');
                }
                else
                {
                    $this->db->delete('goods_catalog',array('id'=>$id));
                    redirect('/goods/');
                }
            }
            else
            {
                redirect('/goods/');
            }
        }



        public function add_product($id)
        {
                $this->data['header'] = $this->reload_header('Добавить продукт');
                $this->data['footer'] = $this->reload_footer();
                $this->data['error'] = $this->session->userdata('error');
                $this->data['cat_id'] = $id;
                $this->data['product_name'] = $this->session->userdata('product_name');
                $this->data['product_objem'] = $this->session->userdata('product_objem');
                $this->data['product_cost'] = $this->session->userdata('product_cost');
                $this->data['product_ves'] = $this->session->userdata('product_ves');
                $this->session->unset_userdata(array('product_ves'=>'','product_objem'=>'','product_cost'=>'','product_name'=>'','error'=>''));
                $this->load->view('goods/add_product',  $this->data);
            
        }
        
        
        public function save_product($id=0)
        {
            $this->session->set_userdata('product_name',$this->input->post('product_name'));
            $this->session->set_userdata('product_objem',$this->input->post('product_objem'));
            $this->session->set_userdata('product_ves',$this->input->post('product_ves'));
            $this->session->set_userdata('product_cost',$this->input->post('product_cost'));
            if($id && $id > 0 && is_numeric($id))
            {
                
                if(!$this->input->post('product_name') || !$this->input->post('product_cost'))
                {
                    $this->session->set_userdata('error','Заполните обязательные поля!');
                    redirect('/goods/add_product/'.$id);
                }
                else
                {
                    $this->db->insert('goods',array(
                        'id'=>'',
                        'name'=>  $this->input->post('product_name'),
                        'catalog_id'=>$id,
                        'ves'=>$this->input->post('product_ves'),
                        'objem'=>$this->input->post('product_objem'),
                        'cost'=>$this->input->post('product_cost')
                    ));
                    redirect('/goods/catalog/'.$id);
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран.');
                redirect('/goods/');
            }
        }

        public function delete_good($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods',array('id'=>$id))->row();
                if($res->id)
                {
                    $this->db->delete('goods',array('id'=>$res->id));
                    redirect('goods/catalog/'.$res->catalog_id);
                }
                else
                {
                    $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                    redirect('/goods/');
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                redirect('/goods/');
            }
        }
        
        public function edit_good($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods',array('id'=>$id))->row();
                if($res->id)
                {
                    $this->data['header'] = $this->reload_header('Редактировать продукт');
                    $this->data['footer'] = $this->reload_footer();
                    $this->data['error'] = $this->session->userdata('error');
                    $this->data['cat_id'] = $res->catalog_id;
                    $this->data['product_info'] = $res;
                    $this->data['product_name'] = $this->session->userdata('product_name');
                    $this->data['product_objem'] = $this->session->userdata('product_objem');
                    $this->data['product_cost'] = $this->session->userdata('product_cost');
                    $this->data['product_ves'] = $this->session->userdata('product_ves');
                    $this->session->unset_userdata(array('product_ves'=>'','product_objem'=>'','product_cost'=>'','product_name'=>'','error'=>''));
                    $this->load->view('goods/edit_product',  $this->data);
                }
                else
                {
                    $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                    redirect('/goods/');
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                redirect('/goods/');
            }
        }
        
        
        public function save_product_edit($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods',array('id'=>$id))->row();
                if($res->id)
                {
                    
                    $this->session->set_userdata('product_name',$this->input->post('product_name'));
                    $this->session->set_userdata('product_objem',$this->input->post('product_objem'));
                    $this->session->set_userdata('product_ves',$this->input->post('product_ves'));
                    $this->session->set_userdata('product_cost',$this->input->post('product_cost'));
                    if(!$this->input->post('product_name') || !$this->input->post('product_cost'))
                    {
                        $this->session->set_userdata('error','Заполните обязательные поля!');
                        redirect('/goods/edit_good/'.$res->id);
                    }
                    else
                    {
                        $this->db->update('goods',array(
                            'name'=>  $this->input->post('product_name'),
                            'catalog_id'=>$res->catalog_id,
                            'ves'=>$this->input->post('product_ves'),
                            'objem'=>$this->input->post('product_objem'),
                            'cost'=>$this->input->post('product_cost')
                        ),array('id'=>$res->id));
                        redirect('/goods/catalog/'.$res->catalog_id);
                    }
                }
                else
                {
                    $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                    redirect('/goods/');
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран или не выбран продукт.');
                redirect('/goods/');
            }
        }
        
        
        public function edit_type($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
                if($res->id)
                {
                    $this->data['header'] = $this->reload_header('Редактировать категорию');
                    $this->data['footer'] = $this->reload_footer();
                    $this->data['error'] = $this->session->userdata('error');
                    $this->data['cat_id'] = $res->id;
                    $this->data['cat_info'] = $res;
                    $this->data['catalog_name'] = $this->session->userdata('catalog_name');
                    $this->session->unset_userdata(array('product_ves'=>'','product_objem'=>'','product_cost'=>'','product_name'=>'','error'=>''));
                    $this->load->view('goods/edit_type',  $this->data);
                }
                else
                {
                    $this->session->set_userdata('error','Каталог не выбран.');
                    redirect('/goods/');
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран.');
                redirect('/goods/');
            }
        }
        
        public function save_type_edit($id)
        {
            if($id && $id > 0 && is_numeric($id))
            {
                $res = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
                if($res->id)
                {
                    
                    $this->session->set_userdata('catalog_name',$this->input->post('category_name'));
                    if(!$this->input->post('category_name'))
                    {
                        $this->session->set_userdata('error','Заполните обязательные поля!');
                        redirect('/goods/edit_type/'.$res->id);
                    }
                    else
                    {
                        $this->db->update('goods_catalog',array(
                            'name'=>  $this->input->post('category_name'),
                        ),array('id'=>$res->id));
                        redirect('/goods/');
                    }
                }
                else
                {
                    $this->session->set_userdata('error','Каталог не выбран.');
                    redirect('/goods/');
                }
            }
            else
            {
                $this->session->set_userdata('error','Каталог не выбран.');
                redirect('/goods/');
            }
        }
        
        public function photo($id=0)
        {
            $object = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Фотография к категории - '.$object->name,'photo');
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                $this->load->view('goods/photo',  $this->data);
            }
            else
            {
                redirect('/goods');
            }
        }
        
        public function add_photo($id=0,$num_photo='1')
        {
            $object = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Обновление фотографии к '.$object->name);
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                $this->data['num_photo'] = $num_photo;
                $this->load->view('goods/add_photo',  $this->data);
            }
            else
            {
                redirect('/goods');
            }
        }
        
        private function rus2translit($string) {
            $converter = array(
                'а' => 'a',   'б' => 'b',   'в' => 'v',
                'г' => 'g',   'д' => 'd',   'е' => 'e',
                'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
                'и' => 'i',   'й' => 'y',   'к' => 'k',
                'л' => 'l',   'м' => 'm',   'н' => 'n',
                'о' => 'o',   'п' => 'p',   'р' => 'r',
                'с' => 's',   'т' => 't',   'у' => 'u',
                'ф' => 'f',   'х' => 'h',   'ц' => 'c',
                'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
                'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
                'э' => 'e',   'ю' => 'yu',  'я' => 'ya',

                'А' => 'A',   'Б' => 'B',   'В' => 'V',
                'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
                'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
                'И' => 'I',   'Й' => 'Y',   'К' => 'K',
                'Л' => 'L',   'М' => 'M',   'Н' => 'N',
                'О' => 'O',   'П' => 'P',   'Р' => 'R',
                'С' => 'S',   'Т' => 'T',   'У' => 'U',
                'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
                'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
                'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
                'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
            );
            return strtr($string, $converter);
        }
        private function str2url($str) {
            $str = $this->rus2translit($str);
            $str = strtolower($str);
            $str = preg_replace('~[^-a-z0-9_]+~u', '_', $str);
            $str = trim($str, "-");
            return $str;
        }
        
        public function save_file_photo($id=0,$num_photo='1')
        {
  
            $object = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
            if($object->id)
            {
                    $file_extension = end((explode(".", $_FILES['house_file']['name'])));
                    $allowed_extension = array('jpg','png','gif','jpeg');
                    if(in_array($file_extension, $allowed_extension))
                    {
                        $path_to_upload = "../upload_files/photos/";
                        $uploadfile = $path_to_upload. $this->str2url( basename($_FILES['house_file']['name']));
                        $uploadfile_1 = $uploadfile.'.'.$file_extension;
                        if (move_uploaded_file($_FILES['house_file']['tmp_name'], $uploadfile_1)) {
                            include '../simpleimage.php';
                            $img = new SimpleImage($uploadfile_1);
                            $img->resize(184, 141);
                            $small = $uploadfile."_goods_catalog.".$file_extension;
                            $img->save($small);
                            unlink($uploadfile_1);
                            $this->db->update('goods_catalog',array('url'.$num_photo=>$small),array('id'=>$object->id));
                            redirect('/goods/photo/'.$object->id);
                            
                        } else {
                            $this->session->set_userdata('error','Файл не был загружен. Попробуйте еще раз.');
                            redirect('/goods/add_photo/'.$object->id);
                        }
                    }
                    else
                    {
                        $this->session->set_userdata('error','Выберите файл, который соответствует параметрам.');
                        redirect('/goods/add_photo/'.$object->id);
                    }

            }
            else
            {
                redirect('/goods');
            }
        }
        
        
        
        public function delete_photo($id=0,$num_photo='1')
        {
            $object = $this->db->get_where('goods_catalog',array('id'=>$id))->row();
            if($object->id)
            {
                unlink($object->url);
                $this->db->update('goods_catalog',array('url'.$num_photo=>''),array('id'=>$object->id));
                redirect('/goods/photo/'.$object->id);
            }
            else
            {
                redirect('/goods');
            }
        }
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */