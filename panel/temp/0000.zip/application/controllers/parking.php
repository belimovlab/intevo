<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Parking extends CI_Controller {

        var $data;

        private function reload_header($title='',$css='')
       {
           $this->data['title']  = $title ? $title : SITE_TITLE;
           $this->data['css']   = array_unique(explode(',',$css));
           return $this->load->view('theme/header.php',  $this->data, TRUE);
       }


       private function reload_footer($js= '')
       {
           $this->data['js']   = array_unique(explode(',',$js));
           return $this->load->view('theme/footer.php',  $this->data, TRUE);
       }

       function __construct() {
           parent::__construct();
           $this->data['menu_active'] = 'nedvizhimost';
           $this->data['header'] = $this->reload_header();
           $this->data['footer'] = $this->reload_footer();
       }



        public function index()
        {
            $sql = "
                SELECT 
                    f.id as flat_id,
                    f.cost as flat_cost,
                    h.id as house_id
                FROM parking_flat as f  LEFT JOIN   parking as h  ON (f.house_id = h.id)";

            $this->data['flats'] = $this->db->query($sql)->result();
            $min_cost = 15000000;
            $max_cost = 0;
            foreach($this->data['flats'] as $one)
            {
                $this->data['flat_new'][$one->house_id][] = $one;
                $this->data['flat_new'][$one->house_id]['min_cost'] = $one->flat_cost < $min_cost ? $one->flat_cost : $min_cost;
                $min_cost = $one->flat_cost < $min_cost ? $one->flat_cost : $min_cost;
                $this->data['flat_new'][$one->house_id]['max_cost'] = $one->flat_cost > $max_cost ? $one->flat_cost : $max_cost;
                $max_cost = $one->flat_cost > $max_cost ? $one->flat_cost : $max_cost;
            }

            $this->data['houses'] = $this->db->get('parking')->result();
            $this->data['header'] = $this->reload_header('Парковочные места');
            $this->data['footer'] = $this->reload_footer();
            $this->data['office_info'] = $this->db->get('house_info')->row();
            $this->data['top_3_ned'] = $this->db->limit(3)->order_by('id','desc')->get_where('pages',array('type_page'=>2))->result();
            $this->load->view('parking',  $this->data);
        }
    
        public function view($id)
        {
            $this->data['office_info'] = $this->db->get('house_info')->row();
            $this->data['house_info'] = $this->db->get_where('parking',array('id'=>$id))->row();
            if($this->data['house_info']->id)
            {
                $this->data['header'] = $this->reload_header($this->data['house_info']->name);
                $this->data['house_docs'] = $this->db->get_where('parking_docs',array('house_id'=>$id))->result();
                $this->data['house_photo'] = $this->db->get_where('parking_photo',array('house_id'=>$id))->result();
                $this->data['house_flat'] = $this->db->get_where('parking_flat',array('house_id'=>$id))->result();
                
                $min_cost = 15000000;
                $max_cost = 0;
                
                
                foreach($this->data['house_flat'] as $one)
                {
                    $min_cost = $one->cost < $min_cost ? $one->cost : $min_cost;
                    $max_cost = $one->cost > $max_cost ? $one->cost : $max_cost;
                }

                $this->data['min_cost'] = $min_cost;
                $this->data['max_cost'] = $max_cost;
                
                
                $this->load->view('parking_view',  $this->data);
            }
            else
            {
                $this->data['menu_active'] = '2';
                $this->data['header'] = $this->reload_header('404 ошибка! Нет такой страницы.');
                $this->load->view('main_show_404',  $this->data);
            }
        }
        
        
        public function search()
        {
            $flat  = $this->input->get('flat');
            $cost  = $this->input->get('cost');
            $house = $this->input->get('house');
            $this->data['office_info'] = $this->db->get('house_info')->row();
            $house = $house == 'all' || $house == '' ? $house = -1 : $house;
            $cost = explode(" - ", $cost);
            $min_cost = $cost[0] * 1000000;
            $min_cost =  $min_cost == 0 ? 1: $min_cost;
            $max_cost = $cost[1] * 1000000;
            $flat = is_numeric($flat) && $flat ? $flat : 1;

            $sql = "SELECT 
                
                f.id as flat_id,
                f.etazh as flat_etazh,
                f.nomer as flat_nomer,
                f.cost as flat_cost,
                f.house_id as flat_house_id,
                h.id as house_id,
                h.name as house_name,
                h.start_build as house_start_build,
                h.end_build as house_end_build,
                h.floor as house_floor,
                h.info as house_info,
                h.status as house_status,
                h.main_photo as house_main_photo


            FROM parking_flat as f  LEFT JOIN   parking as h  ON (f.house_id = h.id)  WHERE ";
            
            $sql  = $sql." 1 = '1'";

            if($house == -1)
            {
            }
            else
            {
                $sql  = $sql." AND h.id = '".$house."'";
            }

            if($min_cost || $max_cost)
            {
                $sql  = $sql." AND f.cost BETWEEN ".$min_cost." AND ".$max_cost;
            }

            $this->data['houses'] = $this->db->get('parking')->result();
            $this->data['flats'] = $this->db->query($sql)->result();
            $min_cost = 15000000;
            $max_cost = 0;
            foreach($this->data['flats'] as $one)
            {
                $this->data['flat_new'][$one->house_id][] = $one;
                $this->data['flat_new'][$one->house_id]['min_cost'] = $one->flat_cost < $min_cost ? $one->flat_cost : $min_cost;
                $min_cost = $one->flat_cost < $min_cost ? $one->flat_cost : $min_cost;
                $this->data['flat_new'][$one->house_id]['max_cost'] = $one->flat_cost > $max_cost ? $one->flat_cost : $max_cost;
                $max_cost = $one->flat_cost > $max_cost ? $one->flat_cost : $max_cost;
            }
            
            
            $this->data['komnat_select']   = $flat;
            $this->data['house_select']    = $house;
            $this->data['min_cost_select'] = $min_cost;
            $this->data['max_cost_select'] = $max_cost;
            
            $this->data['header'] = $this->reload_header('Поиск по параметрам');
            $this->load->view('parking_search',  $this->data);
        }


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */