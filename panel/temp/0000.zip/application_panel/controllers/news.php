<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }

    
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }
        

                
        
                
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 8;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }


        
        public function index()
        {
            $this->data['sub_menu_active'] = 'news';
            $this->data['header'] = $this->reload_header('Список новостей','show_message');
            $this->data['footer'] = $this->reload_footer('get_url');
            $this->data['news'] = $this->db->order_by('id','desc')->get('news')->result();
            $this->load->view('news/index',  $this->data);
        }
        
        
        public function add()
        {
            $this->data['sub_menu_active'] = 'news/add';
            $this->data['header'] = $this->reload_header('Добавление новости');
            $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
            $this->data['error'] = $this->session->userdata('error');
            $this->data['page_title'] = $this->session->userdata('page_title');
            $this->data['page_url'] = $this->session->userdata('page_url');
            $this->data['page_content'] = $this->session->userdata('page_content');
            $this->data['meta_keywords'] = $this->session->userdata('meta_keywords');
            $this->data['meta_decsription'] = $this->session->userdata('meta_decsription');
            $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
            $this->data['news'] = $this->db->order_by('id','desc')->get('news')->result();
            $this->load->view('news/add',  $this->data);
        }
        
        
        public function save()
        {
            $this->input->post('page_title')  ?  $this->session->set_userdata('page_title', $this->input->post('page_title'))  :  '';
            $this->input->post('content')  ?  $this->session->set_userdata('page_content', $this->input->post('content'))  :  '';
            $this->input->post('keywords')  ?  $this->session->set_userdata('meta_keywords', $this->input->post('keywords'))  :  '';
            $this->input->post('description')  ?  $this->session->set_userdata('meta_decsription', $this->input->post('description'))  :  '';
            $this->input->post('url')  ?  $this->session->set_userdata('page_url', $this->input->post('url'))  :  '';
            $this->input->post('preview')  ?  $this->session->set_userdata('page_preview', $this->input->post('preview'))  :  '';
            if(!$this->input->post('page_title') || !$this->input->post('url'))
            {
                $this->session->set_userdata('error','Заполните название страницы или ее URL.');
                redirect('/news/add');
            }
            else
            {
                
                $res = $this->db->get_where('news',array('url'=>  $this->input->post('url')))->row();
                if($res->id)
                {
                    $this->session->set_userdata('error','Такой URL уже есть. Поменяйте URL.');
                    redirect('/news/add');
                }
                else
                {
                    $this->db->insert('news',array(
                        'id'=>'',
                        'create_date'=>date('Y-m-d H:i:s'),
                        'title'=>  $this->input->post('page_title'),
                        'url'=>  $this->input->post('url'),
                        'description'=>  $this->input->post('description'),
                        'keywords'=>  $this->input->post('keywords'),
                        'preview'=>  $this->input->post('preview'),
                        'content'=>  $this->input->post('content'),
                        'visible'=>  1
                    ));
                    redirect('/news');
                    
                }
            }
            
            
            
        }

        
        function delete($id=0)
        {
            if($id && $id> 0 && is_numeric($id))
            {
                $this->db->delete('news', array('id'=>$id));
                redirect('/news');
            }
            else
            {
                redirect('/news');
            }
        }
               
        
        
        function edit($id=0)
        {
            if($id && $id> 0 && is_numeric($id))
            {
                $one_page  = $this->db->get_where('news',array('id'=>$id))->row();
                if($one_page->id)
                {
                    $this->data['header'] = $this->reload_header('Редактирование страницы');
                    $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
                    $this->data['error'] = $this->session->userdata('error');
                    $this->data['page_title'] = $this->session->userdata('page_title');
                    $this->data['page_url'] = $this->session->userdata('page_url');
                    $this->data['page_content'] = $this->session->userdata('page_content');
                    $this->data['page_preview'] = $this->session->userdata('page_preview');
                    $this->data['meta_keywords'] = $this->session->userdata('meta_keywords');
                    $this->data['meta_decsription'] = $this->session->userdata('meta_decsription');
                    $this->session->unset_userdata(array('page_title'=>'','page_url'=>'','page_content'=>'','page_preview'=>'','meta_keywords'=>'','meta_decsription'=>'','error'=>''));
                    $this->data['one_page'] = $one_page;
                    $this->load->view('news/edit',  $this->data);
                }
                else
                {
                    redirect('/news');
                }
                
                

            }
            else
            {
                redirect('/news');
            }
        }
        
        
        public function save_edit()
        {
            $page_id = $this->input->post('page_id');
            $this->input->post('page_title')  ?  $this->session->set_userdata('page_title', $this->input->post('page_title'))  :  '';
            $this->input->post('content')  ?  $this->session->set_userdata('page_content', $this->input->post('content'))  :  '';
            $this->input->post('keywords')  ?  $this->session->set_userdata('meta_keywords', $this->input->post('keywords'))  :  '';
            $this->input->post('description')  ?  $this->session->set_userdata('meta_decsription', $this->input->post('description'))  :  '';
            $this->input->post('url')  ?  $this->session->set_userdata('page_url', $this->input->post('url'))  :  '';
            $this->input->post('preview')  ?  $this->session->set_userdata('page_preview', $this->input->post('preview'))  :  '';
            if(!$this->input->post('page_title') || !$this->input->post('url'))
            {
                $this->session->set_userdata('error','Заполните название страницы или ее URL.');
                redirect('/news/edit/'.$page_id);
            }
            else
            {
                
                $res = $this->db->get_where('pages',array('url'=>  $this->input->post('url')))->row();
                if($res->id && $res->id != $page_id)
                {
                    $this->session->set_userdata('error','Такой URL уже есть. Поменяйте URL.');
                    redirect('/news/edit/'.$page_id);
                }
                else
                {
                    $this->db->update('news',array(
                        'create_date'=>date('Y-m-d H:i:s'),
                        'title'=>  $this->input->post('page_title'),
                        'url'=>  $this->input->post('url'),
                        'description'=>  $this->input->post('description'),
                        'keywords'=>  $this->input->post('keywords'),
                        'content'=>  $this->input->post('content'),
                        'preview'=>  $this->input->post('preview'),
                    ),array(
                        'id'=>$page_id
                    ));
                    redirect('/news');
                }
            }
        }
        
        
        public function photo($id=0)
        {
            if($id && $id> 0 && is_numeric($id))
            {
                $one_page  = $this->db->get_where('news',array('id'=>$id))->row();
                if($one_page->id)
                {
                    $this->data['sub_menu_active'] = 'news';
                    $this->data['header'] = $this->reload_header('Фотография к новости','news_photo');
                    $this->data['footer'] = $this->reload_footer();
                    $this->data['one_page'] = $one_page;
                    $this->load->view('news/photo',  $this->data);
                }
                else
                {
                    redirect('/news');
                }
            }
            else
            {
                redirect('/news');
            }
        }
        
        public function add_photo($id=0)
        {
            $object = $this->db->get_where('news',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Загрузка фотографии к новости');
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'error'=>''
                ));
                $this->load->view('news/add_photo',  $this->data);
            }
            else
            {
                redirect('/news');
            }
        }
        
        
        
        public function save_file_photo($id=0)
        {
  
            $object = $this->db->get_where('news',array('id'=>$id))->row();
            if($object->id)
            {
                    $file_extension = end((explode(".", $_FILES['news_file']['name'])));
                    $allowed_extension = array('jpg','png','gif','jpeg','JPG','GIF','JPEG','PNG');
                    
                    echo $file_extension;
                    

                    if(in_array($file_extension, $allowed_extension))
                    {
                        $path_to_upload = "../upload_files/photos/".$object->id;
                        $uploadfile = $path_to_upload.mktime()."_". $this->str2url( basename($_FILES['news_file']['name']));
                        $uploadfile_1 = $uploadfile.'.'.$file_extension;
                        if (move_uploaded_file($_FILES['news_file']['tmp_name'], $uploadfile_1)) {
                            
                            include '../simpleimage.php';
                            $img = new SimpleImage($uploadfile_1);
                            $img->resize(468, 264);
                            $small = $uploadfile."_small.".$file_extension;
                            $img->save($small);
                            $this->db->update('news',array('image_url'=>$small),array('id'=>$object->id));
                            redirect('/news/photo/'.$object->id);
                        } else {
                            $this->session->set_userdata('error','Файл не был загружен. Попробуйте еще раз.');
                            redirect('/news/add_photo/'.$object->id);
                        }

                    }
                    else
                    {
                        $this->session->set_userdata('error','Выберите файл, который соответствует параметрам.');
                        redirect('/news/add_photo/'.$object->id);
                    }
            }
            else
            {
                redirect('/news');
            }
        }
        
        private function rus2translit($string) {
            $converter = array(
                'а' => 'a',   'б' => 'b',   'в' => 'v',
                'г' => 'g',   'д' => 'd',   'е' => 'e',
                'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
                'и' => 'i',   'й' => 'y',   'к' => 'k',
                'л' => 'l',   'м' => 'm',   'н' => 'n',
                'о' => 'o',   'п' => 'p',   'р' => 'r',
                'с' => 's',   'т' => 't',   'у' => 'u',
                'ф' => 'f',   'х' => 'h',   'ц' => 'c',
                'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
                'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
                'э' => 'e',   'ю' => 'yu',  'я' => 'ya',

                'А' => 'A',   'Б' => 'B',   'В' => 'V',
                'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
                'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
                'И' => 'I',   'Й' => 'Y',   'К' => 'K',
                'Л' => 'L',   'М' => 'M',   'Н' => 'N',
                'О' => 'O',   'П' => 'P',   'Р' => 'R',
                'С' => 'S',   'Т' => 'T',   'У' => 'U',
                'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
                'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
                'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
                'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
            );
            return strtr($string, $converter);
        }
        private function str2url($str) {
            $str = $this->rus2translit($str);
            $str = strtolower($str);
            $str = preg_replace('~[^-a-z0-9_]+~u', '_', $str);
            $str = trim($str, "-");
            return $str;
        }
        
        
        public function delete_photo($id=0)
        {
            $object = $this->db->get_where('news',array('id'=>$id))->row();
            if($object->id)
            {
                unlink($object->image_url);
                $this->db->update('news',array('image_url'=>''),array('id'=>$object->id));
                redirect('/news/photo/'.$object->house_id);
            }
            else
            {
                redirect('/news');
            }
        }
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */