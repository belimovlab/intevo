<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/parking/photo/'.$object->id)?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/parking/save_file_photo/'.$object->id)?>"  enctype="multipart/form-data"  method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="house_file_name">Описание фотографии <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="house_file_name" placeholder="Описание фотографии" name="house_file_name">
                    </p>
                    
                    <p>
                        <label for="house_file">Выберите файл загрузки <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле. Только файлы типа   JPG, PNG, GIF</span></label>
                        <input type="file" class="form-control" id="house_file" name="house_file">
                    </p>
                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Загрузить файл</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>