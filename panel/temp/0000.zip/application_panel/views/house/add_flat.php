<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/view/'.$object->id)?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться без сохранения</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <div class="panel-body">
                <section class="panel">
                    <form  action="<?php echo base_url('/house/save_flat/'.$object->id)?>" method="POST">
                    <?php if($error):?>
                        <p style="color: red; text-align: center; font-size: 12px;"><?php echo $error;?></p>
                    <?php endif;?>
                    <p>
                        <label for="etazh">Этаж <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле. ТОЛЬКО ЧИСЛО!</span></label>
                        <input type="text" class="form-control" id="etazh" placeholder="Этаж" name="etazh" value="<?php echo $etazh ? htmlspecialchars($etazh) : '';?>">
                    </p>
                    <p>
                        <label for="nomer">Номер квартиры <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле. ТОЛЬКО ЧИСЛО!</span></label>
                        <input type="text" class="form-control" id="nomer" placeholder="Номер квартиры" name="nomer" value="<?php echo $nomer ? htmlspecialchars($nomer) : '';?>">
                    </p>
                    <p>
                        <label for="square">Площадь <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="square" placeholder="Площадь" name="square" value="<?php echo $square ? htmlspecialchars($square) : '';?>">
                    </p>
                    <p>
                        <label for="komnat">Кол-во комнат <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="komnat" placeholder="Кол-во комнат" name="komnat" value="<?php echo $komnat ? htmlspecialchars($komnat) : '';?>">
                    </p>
                    <p>
                        <label for="permetr">Стоимость метра.кв. <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="permetr" placeholder="Стоимость метра.кв." name="permetr" value="<?php echo $permetr ? htmlspecialchars($permetr) : '';?>">
                    </p>
                    <p>
                        <label for="cost">Цена <span style="font-weight: lighter; font-size: 10px; color: red;">* Обязательное поле.</span></label>
                        <input type="text" class="form-control" id="cost" placeholder="Цена" name="cost" value="<?php echo $cost ? htmlspecialchars($cost) : '';?>">
                    </p>

                    <button type="submit" class="btn btn-success" style="margin-top: 20px;"><i class="icon-save"></i> Добавить новую квартиру</button>
                    </form>
                </section>
             </div>
        </section>
        
        
        
        
        
        
        
    </div>
</div>
<?php echo $footer;?>