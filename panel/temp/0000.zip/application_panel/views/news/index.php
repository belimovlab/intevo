<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/news/add')?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить новость</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                Список новостей сайта
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Заголовок Новости</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($news) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($news as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $one->title?></td>
                            <td>
                                <button class="btn btn-success btn-xs tooltips get_url" data-original-title="Получить URL страницы" data-placement="bottom" data-page_url="<?php echo $one->id?>" data-url_link="<?php echo SITE_URL."news/".$one->url?>"><i class="icon-link"></i></button>
                                <a  href="<?php echo base_url('/news/edit/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a  href="<?php echo base_url('/news/photo/'.$one->id)?>" class="btn btn-warning btn-xs tooltips" data-original-title="Фотография" data-placement="bottom"><i class="icon-camera"></i></a>
                                <a  href="<?php echo base_url('/news/delete/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="4" style="text-align: center;">У вас нет новостей на сайте.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
    
    <div class="show_message">
        <div class="message_content">
            <div class="close_link"><i class="icon-remove"></i> закрыть</div>
            <div class="message_content_link">
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    
</div>
<?php echo $footer;?>