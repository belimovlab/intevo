<?php echo $header;?>

<div class="production nedvizhimost carier">
				<div class="container">
					<div class="left-sidebar">
						<div class="menu-wrapper">
							<p class="left-sidebar-title no-icon-sidebar-title">Разделы сайта</p>
							<ul class="sidebar-menu">

                                                            <li><a href="<?php echo base_url('/')?>">Главная</a></li>
                                                            <li><a href="<?php echo base_url('/about')?>">О компании</a></li>
                                                            <li><a href="<?php echo base_url('/nedvizhimost')?>">Недвижимость</a></li>
                                                            <li><a href="<?php echo base_url('/produkciya')?>">Продукция ЖБИ</a></li>
                                                            <li><a href="<?php echo base_url('/tendery')?>">Тендеры</a></li>
                                                            <li><a href="<?php echo base_url('/cariera')?>">Карьера</a></li>

							</ul>
						</div>


					</div>
					<div class="right-block">
						<div class="broods">
							<ul>
								<li><a href="<?php echo base_url('/')?>">Главная</a></li>
								<li><a href="<?php echo base_url('/')?>">Ошибка</a></li>
							</ul>
						</div>
						<div class="text">
							<div class="right-block-title">
								<p><?php echo $title;?></p>
							</div>
							<p>
                                                            Страница по данному URL недоступна. Ее либо нет, либо она была удалена.
                                                        </p>
                                                        <p>
                                                            Вы можете вернуться назад или перейти в любой другой раздел сайта.
                                                        </p>
                                                </div>
					</div>
				</div>



<?php echo $footer;?>