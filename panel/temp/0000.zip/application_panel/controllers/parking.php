<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');






class Parking extends CI_Controller {

        var $data;
        
         private function reload_header($title='',$css='')
        {
            $this->data['title']  = $title ? $title : 'Панель администратора';
            $this->data['css']   = array_unique(explode(',',$css));
            return $this->load->view('theme/header.php',  $this->data, TRUE);
        }
        private function reload_footer($js= '')
        {
            $this->data['js']   = array_unique(explode(',',$js));
            return $this->load->view('theme/footer.php',  $this->data, TRUE);
        }
        function get_index($array, $key)
        {
          $r = array_flip(array_keys($array));
          return $r[$key];
        }    
        function __construct() {
            parent::__construct();
            $this->data['menu_active'] = 13;
            if(!$this->auth->is_loggined())
            {
                redirect('/login');
            }
            $this->data['new_messages'] = $this->db->get_where('messages',array('view'=>1))->num_rows();
        }
        public function index()
        {
            $this->data['sub_menu_active'] = 'parking';
            $this->data['header'] = $this->reload_header('Список жилых объектов','show_message');
            $this->data['footer'] = $this->reload_footer('confirm');
            $this->data['houses'] = $this->db->get('parking')->result();
            $this->load->view('parking/index',  $this->data);
        }
        public function add()
        {
            $this->data['sub_menu_active'] = 'parking/add';
            $this->data['header'] = $this->reload_header('Добавление нового жилого объекта с паркингом','show_message');
            $this->data['footer'] = $this->reload_footer();
            $this->data['house_name'] = $this->session->userdata('house_name');
            $this->data['house_start_build'] = $this->session->userdata('house_start_build');
            $this->data['house_end_build'] = $this->session->userdata('house_end_build');
            $this->data['house_square'] = $this->session->userdata('house_square');
            $this->data['house_floor'] = $this->session->userdata('house_floor');
            $this->data['error'] = $this->session->userdata('error');
            $this->session->unset_userdata(array(
                'house_name'=>'',
                'house_start_build'=>'',
                'house_end_build'=>'',
                'house_square'=>'',
                'house_floor'=>'',
                'error'=>''
            ));
            $this->load->view('parking/add',  $this->data);
        }
        public function save_object()
        {
            if(!$this->input->post('house_name') || !$this->input->post('house_start_build') || !$this->input->post('house_end_build') || !$this->input->post('house_square') || !$this->input->post('house_floor') || !is_numeric($this->input->post('house_floor')))
            {
                $this->session->set_userdata(array(
                    'house_name'=>$this->input->post('house_name'),
                    'house_start_build'=>$this->input->post('house_start_build'),
                    'house_end_build'=>$this->input->post('house_end_build'),
                    'house_square'=>$this->input->post('house_square'),
                    'house_floor'=>$this->input->post('house_floor'),
                    'error'=>'Заполните все поля правильно.'
                ));
                redirect('/parking/add');
            }
            else
            {
                $this->db->insert('parking',array(
                    'id'=>'',
                    'create_date'=>date('Y-m-d H:i:s'),
                    'name'=>  $this->input->post('house_name'),
                    'start_build'=>  $this->input->post('house_start_build'),
                    'end_build'=>  $this->input->post('house_end_build'),
                    'square'=>  $this->input->post('house_square'),
                    'floor'=>  $this->input->post('house_floor')
                ));
                redirect('/parking');
            }
        }
        public function edit($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Редактирование жилого объекта');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_name'] = $this->session->userdata('house_name') != $object->name && $this->session->userdata('house_name')!= '' ? $this->session->userdata('house_name') : $object->name ;
                $this->data['house_start_build'] = $this->session->userdata('house_start_build') != $object->start_build && $this->session->userdata('house_start_build')!= ''  ? $this->session->userdata('house_start_build') : $object->start_build ;
                $this->data['house_end_build'] = $this->session->userdata('house_end_build') != $object->end_build  && $this->session->userdata('house_end_build')!= '' ? $this->session->userdata('house_end_build') : $object->end_build ;
                $this->data['house_square'] = $this->session->userdata('house_square') != $object->square && $this->session->userdata('house_square')!= ''  ? $this->session->userdata('house_square') : $object->square ;
                $this->data['house_floor'] = $this->session->userdata('house_floor') != $object->floor && $this->session->userdata('house_floor')!= ''  ? $this->session->userdata('house_floor') : $object->floor ;
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'house_name'=>'',
                    'house_start_build'=>'',
                    'house_end_build'=>'',
                    'house_square'=>'',
                    'house_floor'=>'',
                    'error'=>''
                ));
                $this->data['object'] = $object;
                $this->load->view('parking/edit',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function update_object($id)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                if(!$this->input->post('house_name') || !$this->input->post('house_start_build') || !$this->input->post('house_end_build') || !$this->input->post('house_square') || !$this->input->post('house_floor') || !is_numeric($this->input->post('house_floor')))
                {
                    $this->session->set_userdata(array(
                        'house_name'=>$this->input->post('house_name'),
                        'house_start_build'=>$this->input->post('house_start_build'),
                        'house_end_build'=>$this->input->post('house_end_build'),
                        'house_square'=>$this->input->post('house_square'),
                        'house_floor'=>$this->input->post('house_floor'),
                        'error'=>'Заполните все поля правильно.'
                    ));
                    redirect('/parking/edit/'.$object->id);
                }
                else
                {
                    $this->db->update('parking',array(
                        'name'=>  $this->input->post('house_name'),
                        'start_build'=>  $this->input->post('house_start_build'),
                        'end_build'=>  $this->input->post('house_end_build'),
                        'square'=>  $this->input->post('house_square'),
                        'floor'=>  $this->input->post('house_floor')
                    ),array('id'=>$object->id));
                    redirect('/parking');
                }
            }
            else
            {
                redirect('/house');
            }
        }
        public function info($id=0)
        {
            $object = $this->db->select('id,info')->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Редактирование информации жилого объекта');
                $this->data['footer'] = $this->reload_footer('tinymce/tinymce.min,generation_url');
                $this->data['house_info'] = $object->info;
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'error'=>''
                ));
                $this->data['object'] = $object;
                $this->load->view('parking/info',  $this->data);
            }
            else
            {
                redirect('/house');
            }
        }
        public function save_info($id=0)
        {
            $object = $this->db->select('id,info')->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->db->update('parking',array('info'=>  $this->input->post('house_info')),array('id'=>$object->id));
                redirect('/parking');
            }
            else
            {
                redirect('/parking');
            }
        }
        public function docs($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Список документации к жилому объекту');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_docs'] = $this->db->get_where('parking_docs',array('house_id'=>$object->id))->result();
                $this->data['object'] = $object;
                $this->load->view('parking/docs',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function add_docs($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Загрузка документа к жилому объекту.');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_docs'] = $this->db->get_where('parking_docs',array('house_id'=>$object->id))->result();
                $this->data['object'] = $object;
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'error'=>''
                ));
                $this->load->view('parking/add_docs',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function save_file($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                if($this->input->post('house_file_name') != '')
                {
                    $file_extension = end((explode(".", $_FILES['house_file']['name'])));
                    $allowed_extension = array('doc','xls','xlsx','docx','txt','jpg','png','gif','pdf','rar','zip');
                    if(in_array(strtolower($file_extension), $allowed_extension))
                    {
                        $path_to_upload = "../upload_files/".$object->id;
                        $uploadfile = $path_to_upload.mktime()."_". $this->str2url( basename($_FILES['house_file']['name'])).'.'.$file_extension;
                        if (move_uploaded_file($_FILES['house_file']['tmp_name'], $uploadfile)) {
                            
                            $this->db->insert('parking_docs',array(
                                'id'=>'',
                                'create_date'=>date('Y-m-d H:i:s'),
                                'house_id'=>$object->id,
                                'url' => $uploadfile,
                                'name' =>  $this->input->post('house_file_name'),
                                'extension' => $this->get_icon_to_extension($file_extension)
                            ));
                            redirect('/parking/docs/'.$object->id);
                        } else {
                            $this->session->set_userdata('error','Файл не был загружен. Попробуйте еще раз.');
                            redirect('/parking/add_docs/'.$object->id);
                        }
                    }
                    else
                    {
                        $this->session->set_userdata('error','Выберите файл, который соответствует параметрам.');
                        redirect('/parking/add_docs/'.$object->id);
                    }
                }
                else
                {
                    $this->session->set_userdata('error','Заполните все поля!');
                    redirect('/parking/add_docs/'.$object->id);
                }
            }
            else
            {
                redirect('/parking');
            }
        }
        private function get_icon_to_extension($extension_name='')
        {
            
            switch($extension_name)
            {
                default: 
                    $icon_name = 'code-o';
                break;
                case 'doc':
                    $icon_name = 'word-o';
                break;
                case 'docx':
                    $icon_name = 'word-o';
                break;
                case 'xls':
                    $icon_name = 'excel-o';
                break;
                case 'xlsx':
                    $icon_name = 'excel-o';
                break;
                case 'pdf':
                    $icon_name = 'pdf-o';
                break;
                case 'jpg':
                    $icon_name = 'image-o';
                break;
                case 'jpg':
                    $icon_name = 'image-o';
                break;
                case 'png':
                    $icon_name = 'image-o';
                break;
                case 'gif':
                    $icon_name = 'image-o';
                break;
                case 'rar':
                    $icon_name = 'zip-o';
                break;
                case 'zip':
                    $icon_name = 'zip-o';
                break;
            }
            
            return $icon_name;
        }
        private function rus2translit($string) {
            $converter = array(
                'а' => 'a',   'б' => 'b',   'в' => 'v',
                'г' => 'g',   'д' => 'd',   'е' => 'e',
                'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
                'и' => 'i',   'й' => 'y',   'к' => 'k',
                'л' => 'l',   'м' => 'm',   'н' => 'n',
                'о' => 'o',   'п' => 'p',   'р' => 'r',
                'с' => 's',   'т' => 't',   'у' => 'u',
                'ф' => 'f',   'х' => 'h',   'ц' => 'c',
                'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
                'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
                'э' => 'e',   'ю' => 'yu',  'я' => 'ya',

                'А' => 'A',   'Б' => 'B',   'В' => 'V',
                'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
                'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
                'И' => 'I',   'Й' => 'Y',   'К' => 'K',
                'Л' => 'L',   'М' => 'M',   'Н' => 'N',
                'О' => 'O',   'П' => 'P',   'Р' => 'R',
                'С' => 'S',   'Т' => 'T',   'У' => 'U',
                'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
                'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
                'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
                'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
            );
            return strtr($string, $converter);
        }
        private function str2url($str) {
            $str = $this->rus2translit($str);
            $str = strtolower($str);
            $str = preg_replace('~[^-a-z0-9_]+~u', '_', $str);
            $str = trim($str, "-");
            return $str;
        }
        public function delete_docs($id)
        {
            $object = $this->db->get_where('parking_docs',array('id'=>$id))->row();
            if($object->id)
            {
                unlink($object->url);
                $this->db->delete('parking_docs',array('id'=>$object->id));
                redirect('/parking/docs/'.$object->house_id);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function photo($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Список фотографий к жилому объекту');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_photos'] = $this->db->get_where('parking_photo',array('house_id'=>$object->id))->result();
                $this->data['object'] = $object;
                $this->load->view('parking/photo',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function add_photo($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Загрузка фотографии к жилому объекту.');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_photos'] = $this->db->get_where('parking_photo',array('house_id'=>$object->id))->result();
                $this->data['object'] = $object;
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'error'=>''
                ));
                $this->load->view('parking/add_photo',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        public function save_file_photo($id=0)
        {
  
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                if($this->input->post('house_file_name') != '')
                {
                    $file_extension = end((explode(".", $_FILES['house_file']['name'])));
                    $allowed_extension = array('jpg','png','gif','jpeg','JPG','GIF','JPEG','PNG');
                    if(in_array($file_extension, $allowed_extension))
                    {
                        $path_to_upload = "../upload_files/photos/".$object->id;
                        $uploadfile = $path_to_upload.mktime()."_". $this->str2url( basename($_FILES['house_file']['name']));
                        $uploadfile_1 = $uploadfile.'.'.$file_extension;
                        if (move_uploaded_file($_FILES['house_file']['tmp_name'], $uploadfile_1)) {
                            
                            include '../simpleimage.php';
                            $img = new SimpleImage($uploadfile_1);
                            $img->resize(187, 105);
                            $small = $uploadfile."_small.".$file_extension;
                            $img->save($small);
                           
                            $this->db->insert('parking_photo',array(
                                'id'=>'',
                                'create_date'=>date('Y-m-d H:i:s'),
                                'house_id'=>$object->id,
                                'url_big' => $uploadfile_1,
                                'url_small' => $small,
                                'title' =>  $this->input->post('house_file_name')
                            ));
                            
                            if($object->main_photo == '')
                            {
                                $this->db->update('parking',array('main_photo'=>$small),array('id'=>$object->id));
                            }
                            redirect('/parking/photo/'.$object->id);
                        } else {
                            $this->session->set_userdata('error','Файл не был загружен. Попробуйте еще раз.');
                            redirect('/parking/add_photo/'.$object->id);
                        }
                    }
                    else
                    {
                        $this->session->set_userdata('error','Выберите файл, который соответствует параметрам.');
                        redirect('/parking/add_photo/'.$object->id);
                    }
                }
                else
                {
                    $this->session->set_userdata('error','Заполните все поля!');
                    redirect('/parking/add_photo/'.$object->id);
                }
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        public function delete_photo($id)
        {
            $object = $this->db->get_where('parking_photo',array('id'=>$id))->row();
            if($object->id)
            {
                unlink($object->url_big);
                unlink($object->url_small);
                $this->db->delete('parking_photo',array('id'=>$object->id));
                redirect('/parking/photo/'.$object->house_id);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        
        
        public function status($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Редактирование статуса строительства жилого объекта');
                $this->data['footer'] = $this->reload_footer();
                $this->data['house_status'] = $this->session->userdata('house_status') != $object->status && $this->session->userdata('house_status')!= '' ? $this->session->userdata('house_status') : $object->status ;
                $this->data['house_percent'] = $this->session->userdata('house_percent') != $object->percent && $this->session->userdata('house_percent')!= ''  ? $this->session->userdata('house_percent') : $object->percent ;
                
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'house_status'=>'',
                    'house_percent'=>'',
                    'error'=>''
                ));
                $this->data['object'] = $object;
                $this->load->view('parking/status',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        public function update_status($id)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                if(!$this->input->post('house_status') || !$this->input->post('house_percent')  || !is_numeric($this->input->post('house_percent')))
                {
                    $this->session->set_userdata(array(
                        'house_status'=>$this->input->post('house_status'),
                        'house_percent'=>$this->input->post('house_percent'),
                        'error'=>'Заполните все поля правильно.'
                    ));
                    redirect('/parking/status/'.$object->id);
                }
                else
                {
                    $this->db->update('parking',array(
                        'status'=>  $this->input->post('house_status'),
                        'percent'=>  $this->input->post('house_percent')
                    ),array('id'=>$object->id));
                    redirect('/parking');
                }
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        public function set_main_photo($photo_id,$house_id)
        {
            $object = $this->db->get_where('parking',array('id'=>$house_id))->row();
            if($object->id)
            {
                $object_photo = $this->db->get_where('parking_photo',array('id'=>$photo_id))->row();
                if($object_photo->id)
                {
                    $this->db->update('parking',array('main_photo'=>$object_photo->url_big),array('id'=>$object->id));
                    redirect('/parking/photo/'.$object->id);
                }
                else
                {
                    redirect('/parking/photo/'.$object->id);
                }
            }
            else
            {
                redirect('/parking');
            }
        }
        
        

        public function view($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Список парковочных мест');
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                $this->data['flats'] = $this->db->order_by('id','asc')->get_where('parking_flat',array('house_id'=>$object->id))->result();
                $this->session->unset_userdata(array(
                    'error'=>''
                ));
                $this->load->view('parking/view',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        
        public function add_flat($id=0)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Добавить квартиру');
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                
                
                $this->data['etazh'] = $this->session->userdata('etazh');
                $this->data['nomer'] = $this->session->userdata('nomer');
                $this->data['square'] = $this->session->userdata('square');
                $this->data['cost'] = $this->session->userdata('cost');
                $this->data['komnat'] = $this->session->userdata('komnat');
                $this->data['permetr'] = $this->session->userdata('permetr');
                $this->data['error'] = $this->session->userdata('error');

                $this->session->unset_userdata(array(
                    'etazh'=>'',
                    'nomer'=>'',
                    'square'=>'',
                    'cost'=>'',
                    'komnat'=>'',
                    'permetr'=>'',
                    'error'=>''
                ));
                $this->load->view('parking/add_flat',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        
        public function save_flat($id)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                if(!$this->input->post('etazh') || !$this->input->post('nomer')  || !$this->input->post('cost')  || !is_numeric($this->input->post('etazh'))   || !is_numeric($this->input->post('nomer')) )
                {
                    $this->session->set_userdata(array(
                        'etazh'=>$this->input->post('etazh'),
                        'nomer'=>$this->input->post('nomer'),
                        'cost'=>$this->input->post('cost'),
                        'error'=>'Заполните все поля правильно.'
                    ));
                    redirect('/parking/add_flat/'.$object->id);
                }
                else
                {
                    $this->db->insert('parking_flat',array(
                        'id'=>'',
                        'create_date'=>date('Y-m-d H:i:s'),
                        'etazh'=>  $this->input->post('etazh'),
                        'nomer'=>  $this->input->post('nomer'),
                        'cost'=>  $this->input->post('cost'),
                        'house_id'=>$object->id
                    ));
                    redirect('/parking/view/'.$object->id);
                }
            }
            else
            {
                redirect('/parking');
            }

        }
        
        public function delete_flat($id)
        {
            $object = $this->db->get_where('parking_flat',array('id'=>$id))->row();
            if($object->id)
            {
                $this->db->delete('parking_flat',array('id'=>$object->id));
                redirect('/parking/view/'.$object->house_id);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        public function edit_flat($id)
        {
            $object = $this->db->get_where('parking_flat',array('id'=>$id))->row();
            if($object->id)
            {
                $this->data['header'] = $this->reload_header('Изменить иноформацию о парковочном месте');
                $this->data['footer'] = $this->reload_footer();
                $this->data['object'] = $object;
                
                
                $this->data['etazh'] = $this->session->userdata('etazh') != $object->etazh && $this->session->userdata('etazh')!= '' ? $this->session->userdata('etazh') : $object->etazh ;
                $this->data['nomer'] = $this->session->userdata('nomer') != $object->nomer && $this->session->userdata('nomer')!= '' ? $this->session->userdata('nomer') : $object->nomer ;
                $this->data['cost'] = $this->session->userdata('cost') != $object->cost && $this->session->userdata('cost')!= '' ? $this->session->userdata('cost') : $object->cost ;

                
                $this->data['error'] = $this->session->userdata('error');
                $this->session->unset_userdata(array(
                    'etazh'=>'',
                    'nomer'=>'',
                    'cost'=>'',
                    'error'=>''
                ));
                $this->load->view('parking/edit_flat',  $this->data);
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        public function update_flat($id)
        {
            $object = $this->db->get_where('parking_flat',array('id'=>$id))->row();
            if($object->id)
            {
                if(!$this->input->post('etazh') || !$this->input->post('nomer')  || !$this->input->post('cost')  || !is_numeric($this->input->post('etazh'))   || !is_numeric($this->input->post('nomer')))
                {
                    $this->session->set_userdata(array(
                        'etazh'=>$this->input->post('etazh'),
                        'nomer'=>$this->input->post('nomer'),
                        'cost'=>$this->input->post('cost'),
                        'error'=>'Заполните все поля правильно.'
                    ));
                    redirect('/parking/edit_flat/'.$object->id);
                }
                else
                {
                    $this->db->update('parking_flat',array(
                        'etazh'=>  $this->input->post('etazh'),
                        'nomer'=>  $this->input->post('nomer'),
                        'cost'=>  $this->input->post('cost')
                    ),array('id'=>$object->id));
                    redirect('/parking/view/'.$object->house_id);
                }
            }
            else
            {
                redirect('/parking');
            }

        }
        
        public function delete($id)
        {
            $object = $this->db->get_where('parking',array('id'=>$id))->row();
            if($object->id)
            {
                $this->db->delete('parking',array('id'=>$object->id));
                redirect('/parking/');
            }
            else
            {
                redirect('/parking');
            }
        }
        
        
        public function info_config()
        {
            $this->data['sub_menu_active'] = 'parking/info';
            $this->data['header'] = $this->reload_header('Информация');
            $this->data['footer'] = $this->reload_footer();
            $this->data['success'] = $this->session->userdata('success');
            $this->session->unset_userdata('success');
            $this->data['error'] = $this->session->userdata('error');
            $this->session->unset_userdata('error');
            $this->data['info'] = $this->db->get('house_info')->row();
            $this->load->view('house/info_config',  $this->data);
        }
        
        
        public function save_info_config()
        {
            $adres = $this->input->post('adres');
            $email = $this->input->post('email');
            $phone = $this->input->post('phone');
            $fax = $this->input->post('fax');
            
            if(!$adres || ! $phone || !$email || !$fax)
            {
                $this->session->set_userdata('error','Заполните все данные.');
                redirect('/parking/info_config');
            }
            else
            {
                $this->db->update('house_info',array(
                    'adres'=> $adres,
                    'email'=>$email,
                    'phone'=>$phone,
                    'fax'=>$fax
                ));
                $this->session->set_userdata('success','Данные изменены.');
                redirect('/parking/info_config');
            }
            
            
            
        }
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */