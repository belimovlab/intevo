<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/house/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться</a>
            <a href="<?php echo base_url('/house/add_photo/'.$object->id)?>" class="btn btn-shadow btn-success"><i class="icon-plus"></i> Загрузить новую фотографию</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <?php echo $title;?>
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Изображение</th>
                    <th>Описание</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($house_photos) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($house_photos as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><img src="<?php echo str_replace("..",'', $one->url_small)?>"/></td>
                            <td><?php echo $one->title?></td>
                            <td>
                                <?php if($one->url_small == $object->main_photo):?>
                                <a  href="<?php echo base_url('/house/set_main_photo/'.$one->id.'/'.$object->id)?>" class="btn btn-success btn-xs tooltips disabled" data-original-title="Сделать главной" data-placement="bottom"><i class="icon-check "></i> Это главная фотография</a>
                                <?else:?>
                                <a  href="<?php echo base_url('/house/set_main_photo/'.$one->id.'/'.$object->id)?>" class="btn btn-success btn-xs tooltips" data-original-title="Сделать главной" data-placement="bottom">Сделать главной</a>
                                <?php endif;?>
                                <a  href="<?php echo base_url('/house/delete_photo/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Вы пока не загрузили ни одиной фотографии.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
        
</div>
<?php echo $footer;?>