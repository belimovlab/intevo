<?php echo $header;?>
<div class="row">
    <div class="col-lg-12">
        <p style="padding-bottom: 10px;">
            <a href="<?php echo base_url('/parking/')?>" class="btn btn-shadow btn-info"><i class="icon-arrow-left"></i> Вернуться к объектам</a>
            <a href="<?php echo base_url('/parking/add_flat/'.$object->id)?>" class="btn btn-shadow btn-primary"><i class="icon-plus"></i> Добавить парковочное место</a>
        </p>
        <section class="panel">
            <header class="panel-heading">
                <b><?php echo $object->name?></b> / Парковочный объект
            </header>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>Этаж</th>
                    <th>Номер паркинга</th>
                    <th>Цена</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($flats) > 0):?>
                    <?php $i=1;?>
                    <?php foreach($flats as $one):?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo "<b>BPB_".$object->id."_".$one->id."</b>";?></td>
                            <td><?php echo $one->etazh;?></td>
                            <td><?php echo $one->nomer;?></td>
                            <td><?php echo $one->cost;?></td>
                            <td>
                                <a href="<?php echo base_url('/parking/edit_flat/'.$one->id)?>" class="btn btn-primary btn-xs tooltips" data-original-title="Редактировать" data-placement="bottom"><i class="icon-pencil"></i></a>
                                <a href="<?php echo base_url('/parking/delete_flat/'.$one->id)?>" class="btn btn-danger btn-xs tooltips" data-original-title="Удалить" data-placement="bottom"><i class="icon-trash "></i></a>
                            </td>
                        </tr>
                        <?php $i++;?>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="9" style="text-align: center;">В этом объекте парковочных мест нет.</td>
                    </tr>
                <?php endif;?>
                </tbody>
            </table>
        </section>
    </div>
</div>
<?php echo $footer;?>