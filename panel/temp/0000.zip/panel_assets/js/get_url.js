/* 
 * Разработка Bepobox.ru
 * Связаться с авторами на сайте http://bepobox.ru
 */


$(document).ready(function(){
    $('.get_url').click(function(){
        var s = $(this).attr('data-page_url');
        $('.show_message').css('display','block');
        $('.message_content_link').html($(this).attr('data-url_link'));
    });
    $('.close_link').click(function(){
        $('.show_message').css('display','none');
        $('.message_content_link').ht,l('');
    });
    
})